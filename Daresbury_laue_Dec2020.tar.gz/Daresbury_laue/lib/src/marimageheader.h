#ifndef FORTRAN_TYPES
#define FORTRAN_TYPES 1
typedef int integer;
typedef float real;
#endif /* FORTRAN_TYPES */

#define PACKIDENTIFIER "\nCCP4 packed image, X: %04d, Y: %04d\n"
#define V2IDENTIFIER "\nCCP4 packed image V2, X: %04d, Y: %04d\n"

typedef struct {
  integer lrecl;
  integer max_rec;
  integer overflow_pixels;
  integer overflow_records;
  integer counts_per_sec_start;
  integer counts_per_sec_end;
  integer exposure_time_sec;
  integer programmed_exp_time_units;
  real programmed_exposure_time;
  real r_min;
  real r_max;
  real p_r;
  real p_l;
  real p_x;
  real p_y;
  real centre_x;
  real centre_y;
  real lambda;
  real distance;
  real phi_start;
  real phi_end;
  real omega;
  real multiplier;
  char scanning_date_time[24];
  char filler[ (600 - 31)*sizeof(integer) ];
} oldmar_part;

typedef struct {
  integer no_overflows;
  integer image_format;
  integer collection_mode;
  integer total_pixels;
  integer rasterx;
  integer rastery;
  integer lambda;
  integer distance;
  integer phi_start;
  integer phi_end;
  integer omega;
  char filler[ (600 - 13)*sizeof(integer) ];
} newmar_part;

typedef struct {
  integer total_pixels_x;
  integer total_pixels_y;
  union {
    oldmar_part oldmar;
    newmar_part newmar;
  } main_part;
} Marimageheader;

typedef struct {
  unsigned int location;
  unsigned int value;
} Marimageoflow;

