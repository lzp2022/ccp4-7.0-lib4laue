/*
*****************************
**   read_full_tiff_     **
*****************************

Purpose: Read an TIFF-format image file and return the image data in 
         an array. The file may have its data in any of the eight
         possible orders and may be byte swapped if needed (the default
         is assumed to  have yf moving fastest and xf 
         slowest). 1-, 2-, and 4-byte data are supported.
         The number of x rasters and number of y rasters supplied
         will be checked against the values in the header.

Derived from read_full_smv_.

*/
/*-Fortran:
         CALL READ_FULL_TIFF (IFD, IDTYPE, KORD, NXRASTS, NYRASTS,
        +                         IVH_BAR, IXROOT, IYROOT, IORD, IMG_FULL,
        +                         MINVAL, MAXVAL, IERR, FNAME)
-end*/
 
/*-Parameters:
IFD      (R)   The file descriptor (see fd)
IDTYPE   (W)   Data type, from file header (1/2/3 for 1/2/4 bytes per pixel)
KORD     (R)   Byte swap code, -1 to swap, otherwise 1
NXRASTS  (R/W) The number of x rasters, may be updated from header
NYRASTS  (R/W) The number of y rasters, may be updated from header
IVH_BAR  (R)   View-object handle for displaying a read progress
               bar >0 on 0 if none required (see vh_bar)
IXROOT   (R)   x root position for progress bar display if
               required (see xroot)
IYROOT   (R)   y root position for progress bar display if 
               required (see yroot)
IORD     (R)   Code for order of the data in the image
IMG_FULL (W)   Array to hold the read data (pass as an
               integer array sufficiently large to hold the
               returned image data) (see img_full)
MINVAL   (W)   The minimum pixel value in the image (see minval)
MAXVAL   (W)   The maximum pixel value in the image (see maxval)
IERR     (W)   Returns the status from the read_full_tiff call
FNAME    (R)   Name of the file, only used if it is necessary to call TIFF libs
-end*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <tiffio.h>
#include <sys/stat.h>
#include <sys/types.h>

/*-C:*/
int read_full_tiff_ (ifd, idtype, iorder, inxrasts, inyrasts, ivh_bar, ixroot, 
 iyroot, iiord, img_full, minval, maxval, ierr, fname)
/*end*/
 
int *ifd, *idtype, *iorder, *inxrasts, *inyrasts, *ivh_bar, *ixroot, *iyroot, 
 *iiord, *ierr;
int img_full[];
                  /* Array returning the read image data. 
                     Normally called with *iiord = 1 or -1, in which case
                     the slower moving index in
                     the returned data is x going from low x to
                     high x and the faster moving index is y going 
                     from low y to high y i.e. the same order as in the
                     file. (W)*/
int *minval;      /* Returns the minimum pixel value in the image (W)*/
int *maxval;      /* Returns the maximum pixel value in the image (W)*/
char *fname;      /* Name of the file, only used if it is necessary to call */
                  /* TIFF libraries, e.g. for compressed data */
{
/*-Parameters:*/
int fd;           /* The file descriptor of the opened image
                     file (R)*/
int order;        /* Whether or not to swap bytes of image data, 
                     +/- for no/yes. May be overridden by byte order
                     determined from image file header. (R) */
int iord;         /* Order of the data in the input film image file
                     in terms of the xf, yf coordinate system as
                     a number from 1 to 8.
                     1   +xf slow   +yf fast
                     2   +xf slow   -yf fast
                     3   -xf slow   +yf fast
                     4   -xf slow   -yf fast
                     5   +yf slow   +xf fast
                     6   +yf slow   -xf fast
                     7   -yf slow   +xf fast
                     8   -yf slow   -xf fast
                     (R)*/
int nxrasts;      /* The number of x rasters (R/W)*/
int nyrasts;      /* The number of y rasters (R/W)*/
int vh_bar;       /* View-object handle (>0) for display bar showing the
                     progress of the read, 0 if none required (R) */
int xroot;        /* The root x position for the top left of the display
                     bar area if required (R)*/
int yroot;        /* The root y position for the top left of the display
                     bar area if required (R)*/
/*end*/
/*-Doc:
Return:  =0 OK; >0 Record number where a read error occurred.
-end*/
  int tiff_libs_on, n_tiff_strips, tiff_rows_per_strip, compressn,
   header_bytes, ityp;
  int *tiff_strip_offsets, *tiff_strip_byte_counts;
  TIFF *tiff_handle;
  tstrip_t tstrip;
  tsize_t tssize;
  tdata_t tdata;
   int i, j, k, l, n, jj, kk, nn, j2;
   int swap;
   int irec;
   int step;
   int nrecs, nrasts;
   int *i4ptr;
   long int offset;
   unsigned short i2temp, i2temp2;
   unsigned short *i2ptr, *buf, *i2tarr, *i2ptr1, *i2ptr2, *j2ptr;
   unsigned char tempc, *cbuf;
   char *header, *tiff_temp, *cp, *cptr;
   int ir, filesize, data_type, bytes_per_line;
   struct stat filestat;

   /* Initialisations */

  fd = *ifd;
  fstat (fd, &filestat);
  filesize = filestat.st_size;
  order = *iorder;
  nxrasts = *inxrasts;
  nyrasts = *inyrasts;
  vh_bar = *ivh_bar;
  xroot = *ixroot;
  yroot = *iyroot;
  iord = *iiord;
  data_type = 2;

   *minval = 1000000;
   *maxval = 0;
   swap = 0;
   if (order<0)
   {
      swap = 1;
      order = -order;
   }
   order *= iord;
   if(order<1||order>8) order=1;
   nrecs = nxrasts;
   nrasts = nyrasts;
   if (order>4) {
     nrecs = nyrasts;
     nrasts = nxrasts;
   }

/* Read header */
   lseek (fd, 0L, 0);
   header = (char *)malloc (4096);
   nn = read (fd,header,4096);
   cp = header;
   i2ptr = (unsigned short *)header;
   if (*i2ptr != 18761) {             /* Not proper TIFF header */
     printf ("Image file does not appear to be a TIFF file.\n");
     *ierr = -1;
     return -1;
   }
/* Initialize some stuff related to strip formatting */
  tiff_libs_on = 0;
/*
  if (tiff_strip_offsets != NULL) {
    free (tiff_strip_offsets);
    free (tiff_strip_byte_counts);
    tiff_strip_offsets = NULL;
    tiff_strip_byte_counts = NULL;
  }
*/
  tiff_strip_offsets = NULL;
  tiff_strip_byte_counts = NULL;
  header_bytes = 4096;

  i2ptr += 2;                                /* Get start of tagged data */
  i2temp = *i2ptr;
  k = i2temp;
  i2ptr++;
  i2temp2 = *i2ptr;
  if (i2temp2 > 0) {                /* Tagged data are after image - assume */
    j = i2temp2;                    /* no problem with byte order */
    k += (65536 * j);
  }
  else {                       /* Tagged data are probably before image, but */
    if (i2temp > 256) {        /* let's check */
      swab ((void *)&i2temp,(void *)&i2temp2,2);
      if (i2temp2 <= 256) {    /* Yes (probably), but need to swap data */
        if (swap == 0)
          swap = 1;
        k = i2temp2;
      }
      else {                   /* No, after image after all - swap if told to */
        if (swap == 1)
          k = i2temp2;
      }
    }
  }
/* printf ("start of tagged data %d\n",k); */
  tiff_temp = NULL;
  if (k > 4096) {
    tiff_temp = (char *)malloc(filesize);
    offset = 0;
    lseek (fd, 0, SEEK_SET);
    nn = read( fd, tiff_temp, filesize);
    if (nn < filesize) {
      fprintf(stderr, "read_full_tiff: read error.\n");
      *ierr = -1;
      return -1;
    }
    cp = tiff_temp;
    k = 0;
  }
  jj = 0;
  i2ptr = k/2 + (unsigned short int *)cp;
  if (swap > 0)
    swab ((void *)i2ptr,(void *)&i2temp,2);
  else
    i2temp = *i2ptr;
  n = i2temp;                         /* Number of tagged items */
/* printf ("Number tagged items %d\n",n); */
  i2ptr++;
  for (i = 0; i < n; i++) {
    if (swap > 0)
      swab ((void *)i2ptr,(void *)&i2temp,2);
    else
      i2temp = *i2ptr;
    if (i2temp == 256)  {                /* Pixels per record */
      j2ptr = i2ptr + 1;
      ityp = *j2ptr;
      if (ityp == 3) {
        j2ptr = i2ptr + 4;
        if (swap > 0) {
          swab ((void *)j2ptr,(void *)&j2,2);
          nrasts = j2;
        }
        else
          nrasts = *j2ptr;
      }
      else {
        i4ptr = (int *)i2ptr + 2;
        if (swap > 0) {
          swab ((void *)i4ptr,(void *)&j,4);
          nrasts = (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
        }
        else
          nrasts = *i4ptr;
      }
    }
    else if (i2temp == 257) {            /* Number of records */
      j2ptr = i2ptr + 1;
      ityp = *j2ptr;
      if (ityp == 3) {
        j2ptr = i2ptr + 4;
        if (swap > 0) {
          swab ((void *)j2ptr,(void *)&j2,2);
          nrecs = j2;
        }
        else
          nrecs = *j2ptr;
      }
      else {
        i4ptr = (int *)i2ptr + 2;
        if (swap > 0) {
          swab ((void *)i4ptr,(void *)&j,4);
          nrecs = (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
        }
        else
          nrecs = *i4ptr;
      }
    }
    else if (i2temp == 258) {            /* Bits per pixel */
      j2ptr = i2ptr + 1;
      ityp = *j2ptr;
      if (ityp == 3) {
        j2ptr = i2ptr + 4;
        if (swap > 0) {
          swab ((void *)j2ptr,(void *)&j2,2);
          jj = j2;
        }
        else
          jj = *j2ptr;
      }
      else {
        i4ptr = (int *)i2ptr + 2;
        if (swap > 0) {
          swab ((void *)i4ptr,(void *)&j,4);
          jj = (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
        }
        else
          jj = *i4ptr;
      }
/* printf ("Bits per pixel %d\n",jj); */
      if (jj == 32)
        data_type = 3;
      else if (jj == 16)
        data_type = 2;
      else if (jj == 8)
        data_type = 1;
      else
        data_type = 2;
    }
    else if (i2temp == 259) {            /* Compression */
      j2ptr = i2ptr + 1;
      ityp = *j2ptr;
      if (ityp == 3) {
        j2ptr = i2ptr + 4;
        if (swap > 0) {
          swab ((void *)j2ptr,(void *)&j2,2);
          compressn = j2;
        }
        else
          compressn = *j2ptr;
      }
      else {
        i4ptr = (int *)i2ptr + 2;
        if (swap > 0) {
          swab ((void *)i4ptr,(void *)&j,4);
          compressn = (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
        }
        else
          compressn = *i4ptr;
      }
    }
    else if (i2temp == 273) {            /* Start of image data */
/* 
 *  Note that for TIFF files header_bytes is actually the start of the
 *  image data. If the TIFF tags are before the data, header_bytes will
 *  also be the length of the headers, but if tags are after data this is
 *  not the case.
 */
/*    i4ptr = (int *)i2ptr + 2; */
      i4ptr = (int *)i2ptr + 1;        /* Assume number will always be 4-byte */
      if (swap > 0) {
        swab ((void *)i4ptr,(void *)&j,4);
        n_tiff_strips = (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
      }
      else
        n_tiff_strips = *i4ptr;
                               /* Uncompressed data, can read it all at once */
      if (compressn == 1) {
        if (n_tiff_strips > 1) {
          printf (
"Warning - multiple strips of data specified, assuming we can combine them.\n");
        }
        i4ptr = (int *)i2ptr + 2;
        if (swap > 0) {
          swab ((void *)i4ptr,(void *)&j,4);
          k = (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
        }
        else
          k = *i4ptr;
        if (n_tiff_strips > 1) {   /* If multiple values, number is a pointer */
          if (tiff_temp == NULL)   /* rather than a value */
            cp = header + k;
          else
            cp = tiff_temp + k;
          i4ptr = (int *)cp;
          if (swap > 0) {
            swab ((void *)i4ptr,(void *)&j,4);
            header_bytes = (((j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
          }
          else
            header_bytes = *i4ptr;
        }
        else
          header_bytes = k;
        offset = k;
      }
      else {                   /* Compressed data, may be in multiple strips */
        tiff_libs_on = 1; /* Will have to use TIFF library calls to read data */
        if (n_tiff_strips > 1) {
          tiff_strip_offsets = (int *)malloc (n_tiff_strips * sizeof (int));
          tiff_strip_byte_counts = (int *)malloc (n_tiff_strips * sizeof (int));
          i4ptr = (int *)i2ptr + 2;
          for (i = 0; i < n_tiff_strips; i++) {
            if (swap > 0) {
              swab ((void *)i4ptr,(void *)&j,4);
              k = (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
            }
            else
              k = *i4ptr;
            tiff_strip_offsets[i] = k;
            if (i == 0) {
              if (tiff_temp == NULL)
                cp = header + k;
              else
                cp = tiff_temp + k;
              i4ptr = (int *)cp;
              if (swap > 0) {
                swab ((void *)i4ptr,(void *)&j,4);
                header_bytes = (((j)&0xFFFF) << 16) | 
                 (( (j)&0xFFFF0000) >> 16);
              }
              else
                header_bytes = *i4ptr;
            }
            i4ptr++;
          }
        }
      }
    }
    else if (i2temp == 278) {            /* Rows per strip */
      j2ptr = i2ptr + 1;
      ityp = *j2ptr;
      if (ityp == 3) {
        j2ptr = i2ptr + 4;
        if (swap > 0) {
          swab ((void *)j2ptr,(void *)&j2,2);
          tiff_rows_per_strip = j2;
        }
        else
          tiff_rows_per_strip = *j2ptr;
      }
      else {
        i4ptr = (int *)i2ptr + 2;
        if (swap > 0) {
          swab ((void *)i4ptr,(void *)&j,4);
          tiff_rows_per_strip = (( (j)&0xFFFF) << 16) | 
           (( (j)&0xFFFF0000) >> 16);
        }
        else
          tiff_rows_per_strip = *i4ptr;
      }
    }
    else if (i2temp == 279) {            /* Strip byte counts */
      j2ptr = i2ptr + 1;
      ityp = *j2ptr;
      i4ptr = (int *)i2ptr + 1;
      kk = *i4ptr;
      if (kk != n_tiff_strips) {
        printf ("Warning - problem with number of strips in TIFF header!\n");
      }
      if ((n_tiff_strips > 1) && (compressn != 1)) {
        i4ptr = (int *)i2ptr + 2;
        for (i = 0; i < n_tiff_strips; i++) {
          if (swap > 0) {
            swab ((void *)i4ptr,(void *)&j,4);
            k = (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
          }
          else
            k = *i4ptr;
          tiff_strip_byte_counts[i] = k;
          i4ptr++;
        }
      }
    }
    i2ptr += 6;
  }
  if (order > 4) {
    if ((nrecs != nyrasts) || (nrasts != nxrasts))
      fprintf (stderr,
"Warning, input and header dimensions do not match:\n   %d x %d vs. %d x %d\n",
       nxrasts,nyrasts,nrasts,nrecs);
  }
  else {
    if ((nrecs != nxrasts) || (nrasts != nyrasts))
      fprintf (stderr,
"Warning, input and header dimensions do not match:\n   %d x %d vs. %d x %d\n",
       nxrasts,nyrasts,nrecs,nrasts);
  }

   if (vh_bar>0) xdl_progress_bar (vh_bar, xroot, yroot, "Read progress", 0, 
                                   120, nrecs, 2, 5);
   
   /* Read data */

   if (tiff_libs_on == 1) {        /* Set up to read strips from TIFF file */
     offset = 0;
     lseek (fd, offset, SEEK_SET);
     close (fd);
     tiff_handle = TIFFOpen (fname, "r");
   }
   switch (data_type) {
     case 1:
       bytes_per_line = nrasts;
       break;
     case 2:
       bytes_per_line = nrasts*2;
       break;
     case 3:
       bytes_per_line = nrasts*4;
       break;
     default:
       bytes_per_line = nrasts*2;
   }
   if (tiff_libs_on == 1) {         /* Read compressed data, all at once */
     i2tarr = (unsigned short int *)malloc (
      (bytes_per_line/2)*nrecs*sizeof(unsigned short));
     i2ptr = i2tarr;
     for (i = 0; i < n_tiff_strips; i++) {
       tstrip = i;
       tssize = -1;
       tdata = (tdata_t)i2ptr;
       kk = TIFFReadEncodedStrip (tiff_handle, tstrip, tdata, tssize);
       i2ptr += (kk/2);
     }
     TIFFClose (tiff_handle);
     i2ptr = i2tarr;
     cbuf = (unsigned char *) i2tarr;
     i4ptr = (int *)i2tarr;
     for (ir=0;ir<nrecs;++ir) {
       switch (order) {              /* Rearrange as necessary */
         case 1:
            j = ir*nrasts;
            step = 1;
            break;
         case 2:
            j = (ir+1)*nrasts - 1;
            step = -1;
            break;
         case 3:
            j = (nrecs-ir-1)*nrasts;
            step = 1;
            break;
         case 4:
            j = (nrecs-ir)*nrasts - 1;
            step = -1;
            break;
         case 5:
            j = ir;
            step = nrecs;
            break;
         case 6:
            j = nrecs - 1 - ir;
            step = nrecs;
            break;
         case 7:
            j = (nrasts-1)*nrecs + ir;
            step = -nrecs;
            break;
         case 8:
            j = nrasts*nrecs - 1 - ir;
            step = -nrecs;
            break;
       }
       if (swap) {
         if (data_type > 1) {
           l=0;
           for (k=0;k<(bytes_per_line/2);++k) {
             tempc = cbuf[l];
             cbuf[l] = cbuf[l+1];
             cbuf[l+1] = tempc;
             l += 2;
           }
           if (data_type == 3) {
             l=0;
             for (k=0;k<nrasts;++k) {
               i2ptr1 = i2ptr + l;
               i2ptr2 = i2ptr + l + 1;
               i2temp = *i2ptr1;
               *i2ptr1 = *i2ptr2;
               *i2ptr2 = i2temp;
               l += 2;
             }
           }
         }
       }
       for (k=0;k<nrasts;++k) {
         if (data_type == 1) {
           cptr = (char *)img_full + j;
           *cptr = cbuf[k];
           jj = (int)*cptr;
           if (jj<*minval) 
             *minval = jj;
           if (jj>*maxval) 
             *maxval = jj;
         }
         else if (data_type == 3) {
           img_full[j] = *i4ptr;
           i4ptr++;
           if (img_full[j]<*minval) 
             *minval = img_full[j];
           if (img_full[j]>*maxval) {
             *maxval = img_full[j];
/* printf ("max val reset to %d at pixel %d\n",img_full[j], j); */
           }
         }
         else {
           i2ptr = (unsigned short *)img_full + j;
           *i2ptr = buf[k];
           if (buf[k]<*minval) 
             *minval = buf[k];
           if (buf[k]>*maxval) 
             *maxval = buf[k];
         }
         j += step;
       }
       if (vh_bar>0) xdl_progress_bar_value (vh_bar, ir+1);
       irec++;
       i2ptr += (bytes_per_line/2);
       cbuf += bytes_per_line;
       i4ptr += (bytes_per_line/4);
     }
     free (i2tarr);
   }
   else {                       /* Read uncompressed data, one line at a time */
     buf = (unsigned short *) malloc((bytes_per_line/2)*sizeof(unsigned short));
     if (buf==0) {
       *ierr = -1;
       return -1;
     }
     cbuf = (unsigned char *) buf;
     irec = 1;
/*
printf ("order %d, offset %ld bytes_per_line %d\n",order,offset,bytes_per_line);
*/
     lseek (fd, offset, SEEK_SET);
     for (ir=0;ir<nrecs;++ir) {
       i = read (fd, buf, bytes_per_line);
       if (i!=bytes_per_line) {
         printf ("Line %d, wanted %d bytes but got %d\n",ir,bytes_per_line,i);
         break;
       }
       i4ptr = (int *)buf;
       switch (order) {              /* Rearrange as necessary */
         case 1:
            j = ir*nrasts;
            step = 1;
            break;
         case 2:
            j = (ir+1)*nrasts - 1;
            step = -1;
            break;
         case 3:
            j = (nrecs-ir-1)*nrasts;
            step = 1;
            break;
         case 4:
            j = (nrecs-ir)*nrasts - 1;
            step = -1;
            break;
         case 5:
            j = ir;
            step = nrecs;
            break;
         case 6:
            j = nrecs - 1 - ir;
            step = nrecs;
            break;
         case 7:
            j = (nrasts-1)*nrecs + ir;
            step = -nrecs;
            break;
         case 8:
            j = nrasts*nrecs - 1 - ir;
            step = -nrecs;
            break;
       }
       if (swap) {
         if (data_type > 1) {
           l=0;
           for (k=0;k<(bytes_per_line/2);++k) {
             tempc = cbuf[l];
             cbuf[l] = cbuf[l+1];
             cbuf[l+1] = tempc;
             l += 2;
           }
           if (data_type == 3) {
             l=0;
             for (k=0;k<nrasts;++k) {
               i2temp = buf[l];
               buf[l] = buf[l+1];
               buf[l+1] = i2temp;
               l += 2;
             }
           }
         }
       }
       for (k=0;k<nrasts;++k) {
         if (data_type == 1) {
           cptr = (char *)img_full + j;
           *cptr = cbuf[k];
           jj = (int)*cptr;
           if (jj<*minval) 
             *minval = jj;
           if (jj>*maxval) 
             *maxval = jj;
         }
         else if (data_type == 3) {
           img_full[j] = *i4ptr;
           i4ptr++;
           if (img_full[j]<*minval) 
             *minval = img_full[j];
           if (img_full[j]>*maxval) {
             *maxval = img_full[j];
/* printf ("max val reset to %d at pixel %d\n",img_full[j], j); */
           }
         }
         else {
           i2ptr = (unsigned short *)img_full + j;
           *i2ptr = buf[k];
           if (buf[k]<*minval) 
             *minval = buf[k];
           if (buf[k]>*maxval) 
             *maxval = buf[k];
         }
         j += step;
       }
       if (vh_bar>0) xdl_progress_bar_value (vh_bar, ir+1);
       irec++;
     }
     free (buf);
   }
printf ("img_full %d %d %d %d %d %d...\n",img_full[0],img_full[1],img_full[2],
 img_full[3],img_full[4],img_full[5]);
   if ((n_tiff_strips > 1) && (compressn != 1)) {
     free (tiff_strip_offsets);
     free (tiff_strip_byte_counts);
   }
   irec = 0;   
   
   /* Tidy up */

   if (vh_bar>0) xdl_delete_view_object (vh_bar);
   if (order>4) {
     *inxrasts = nrasts;
     *inyrasts = nrecs;
   }
   else {
     *inxrasts = nrecs;
     *inyrasts = nrasts;
   }
   *idtype = data_type;
   *ierr = irec;
   return irec;
}

