/* Declarations for LIRL routines */

int lirl_init (int init_alloc, int inc_alloc, int list_type, int coord_type);
int lirl_addref (int mindx, int h, int k, int l, int ipack, int iplate,
                 int ksym, float xfd, float yfd, float alam, int mult,
                 int minharm, int maxharm, int incharm, float ai, float sigi,
                 float aibox, float sigibox, int ispat, int iclos, int imeas,
                 int ibad, int iovld, int icode);
int lirl_putref (int mindx, int iref, int h, int k, int l, 
                 int ipack, int iplate,
                 int ksym, float xfd, float yfd, float alam, int mult,
                 int minharm, int maxharm, int incharm, float ai, float sigi,
                 float aibox, float sigibox, int ispat, int iclos, int imeas,
                 int ibad, int iovld, int icode);
int lirl_set_ovpix (int mindx, int iref, int num_ovpix);
int lirl_set_outlier (int mindx, int iref, int icode);
int lirl_set_refint (int mindx, int iref, float refint, float sigref);
int lirl_putksym (int mindx, int iref, int ksym);
int lirl_setsym (int mindx, float *rsym, float *rsymiv);
int lirl_numrefs (int mindx);
int lirl_sortord (int mindx);
int lirl_gethkl (int mindx, int iref, int *h, int *k, int *l, int *ksym);
int lirl_hklunq (int mindx, int iref, int *h, int *k, int *l);
int lirl_nodunq (int mindx, int iref, int *nh, int *nk, int *nl, float *alnod);
int lirl_getref (int mindx, int iref, int *h, int *k, int *l, int *ipack, 
                 int *iplate, int *ksym, 
                 float *xfd, float *yfd, float *alam, 
                 int *mult, int *minharm, int *maxharm, int *incharm, 
                 float *ai, float *sigi, float *aibox, float *sigibox,
                 int *ispat, int *iclos, int *imeas, int *ibad, int *iovld, 
                 int *icode);
int lirl_get_ovpix (int mindx, int iref, int *num_ovpix);
int lirl_get_outlier (int mindx, int iref, int *icode);
int lirl_get_refint (int mindx, int iref, float *refint, float *sigref);
int lirl_sort (int mindx, int ityp);
int lirl_delete (int mindx, int ipack, int plate);
int lirl_clear (int mindx);
int lirl_free (int mindx);
int lirl_lsm_start (int mindx, int isign);
int lirl_lsm_next (int idx_arr[], int max_arr, int *nrefs, int mult_inc);
int lirl_lsm_settemp (int mindx, int iref, float abscor_nu, float psi_local,
                      float psi_global, float stol2, float al3c2t, 
                      float abscor_lamfn, float ob_lpfac, int knorm, 
                      int kplsc, int iuse);
int lirl_lsm_setuse (int mindx, int iref, int iuse);
int lirl_lsm_scalobs (int mindx, int iref, int *ipack, int *iplate,
                     float *aint, float *sigint, float *aibox, float *sigibox,
                     float *alam, float *refint, float *abscor_nu, 
                     float *psi_local, float *psi_global, float *stol2, 
                     float *al3c2t, float *abscor_lamfn, float *ob_lpfac, 
                     int *knorm, int *kplsc, int *iuse);
int lirl_lsm_getranges (int mindx, int iref,  int *knorm, int *kplsc,
                       float *abscor_nu, float *psi_loc, float *psi_glob);
int lirl_xxx_del (void * rec, void * client_data);
int lirl_xxx_tounq (int mindx);
int lirl_xxx_fromunq (int mindx);
int lirl_xxx_sorhkl (void * rec1, void * rec2, int * i1, int * i2);
int lirl_xxx_sorpk (void * rec1, void * rec2, int * i1, int * i2);
int lirl_xxx_sorpl (void * rec1, void * rec2, int * i1, int * i2);
int lirl_xxx_sorlam (void * rec1, void * rec2, int * i1, int * i2);
int lirl_xxx_sorxfd (void * rec1, void * rec2, int * i1, int * i2);
int lirl_xxx_soryfd (void * rec1, void * rec2, int * i1, int * i2);
int lirl_xxx_sorint (void * rec1, void * rec2, int * i1, int * i2);
int lirl_xxx_sormul (void * rec1, void * rec2, int * i1, int * i2);
int lirl_xxx_sorhklsgn (void * rec1, void * rec2, int * i1, int * i2);
int lirl_hcf (int ii, int jj);
int lirl_sign (int ii, int jj);
