/* System type dependent flags definition for xdl_view routines */


/* The following flags are set where/as appropriate 

   LINKTYP             Mapping of Fortran called routine name to C routine name
   CHAR_STRING_TYPE    Way in which Fortran strings are passed to 'C'
   VMS                 Set for 'VMS' systems only
   NONBLK_TYPE         Non-blocking input type for Unix systems
   SIGACT_TYPE         Signal handling type for Unix systems

*/

/* Define Link name mapping type:

   LINKTYP = 1     Sun, Convex fx2800-alliant ...

                   xdlf_name  called as   xdlf_name_

   LINKTYP = 2     Ardent Titan ...

                   xdlf_name  called as  XDLF_NAME

   LINKTYP = 3     Vax, hpux, AIX ...

                   xdlf_name  called as  xdlf_name
*/

/* Define character string parameter passing type for use in 'xdlstr'
   routine:

   CHAR_STRING_TYPE = 1  Sun, Convex, Ardent Titan fx2800-alliant ...

                         call xdlstr (ch)  

                         passed as  xdlstr (ch_address, ch_len)

                         where ch_address is the address of the string
                         
                         and   ch_len is the length of the string

   CHAR_STRING_TYPE = 2  Vax ...

                         call xdlstr (ch)

                         passed as xdlstr (ch_descriptor)

                         where ch_descriptor is a pointer to a Vax character
                               descriptor structure.

*/

/* VMS type:

   Defined only for (Vax) VMS systems

*/

/* Non-blocking input type for Unix systems:

          NONBLK_TYPE = 1 for Unix systems which have O_NDELAY flag for
                          non-blocking input selected via the 'fcntl' function.

          NONBLK_TYPE = 2 for Unix systems which have O_NONBLOCK flag for
                          non-blocking input selected via the 'fcntl' function.
                          (This is the POSIX definition)

          NONBLK_TYPE = 0 for VMS systems

          (Some systems may have both available)
*/

/* Signal action type:

          SIGACT_TYPE = 1 for VMS and for many Unix systems 

          SIGACT_TYPE = 2 for POSIX compliant Unix systems

          (Some systems may have both available)
*/

#ifndef _POSIX_SOURCE
#  define _POSIX_SOURCE		/* for posix-isms, where present */
#endif

/*Machine type defined*/

#if defined(__linux__) || defined(__APPLE__)
#define found_mc
#define LINKTYP 1
#define CHAR_STRING_TYPE 1
#define NONBLK_TYPE 2
#define SIGACT_TYPE 2
#endif

#if defined(vms) || defined (VMS) || defined (__VMS__) || defined (__vms__)
#define found_mc
#define VMS 1
#define LINKTYP 3
#define CHAR_STRING_TYPE 2
#define NONBLK_TYPE 0
#define SIGACT_TYPE 1
#endif

#if defined(sgi) || defined(__sgi) || defined(iris)
#define found_mc
#define LINKTYP 1
#define CHAR_STRING_TYPE 1
#define NONBLK_TYPE 2
#define SIGACT_TYPE 2
#endif

#if defined(convex) ||  defined(__convex__)
#define found_mc
#define LINKTYP 1
#define CHAR_STRING_TYPE 1
#define NONBLK_TYPE 2
#define SIGACT_TYPE 2
#endif

#if defined(sparc) || defined(ESV) || defined (solbourne) || defined (sun) || defined (__sun)
#define found_mc
#define LINKTYP 1
#define CHAR_STRING_TYPE 1
#define NONBLK_TYPE 2
#define SIGACT_TYPE 2
#endif

#if defined(sun3)
#define found_mc
#define LINKTYP 1
#define CHAR_STRING_TYPE 1
#define NONBLK_TYPE 1
#define SIGACT_TYPE 1
#endif

#if defined(alliant)
#define found_mc
#define LINKTYP 1
#define CHAR_STRING_TYPE 1
#define NONBLK_TYPE 2
#define SIGACT_TYPE 1
#endif

/* On Ultrix both types for NONBLK_TYPE & SIGACT_TYPE are possible */
#if defined(ultrix) || defined(ULTRIX)
#define found_mc
#define LINKTYP 1
#define CHAR_STRING_TYPE 1
#define NONBLK_TYPE 1
#define SIGACT_TYPE 1
#endif

#if defined(hp700) || defined(hpux) || defined (__hpux)
#define found_mc
#define LINKTYP 3
#define CHAR_STRING_TYPE 1
#define NONBLK_TYPE 1
#define SIGACT_TYPE 1
#endif

#if defined(AIX) || defined (_AIX)
#define found_mc
#define LINKTYP 3
#define CHAR_STRING_TYPE 1
#define NONBLK_TYPE 2
#define SIGACT_TYPE 2
#endif

#if defined(OSF1) || defined(osf) || defined(__OSF1__) || defined(__osf__)
#define found_mc
#define LINKTYP 1
#define CHAR_STRING_TYPE 1
#define NONBLK_TYPE 2
#define SIGACT_TYPE 2
#endif

#if !defined(found_mc)
#define LINKTYP 1
#define CHAR_STRING_TYPE 1
#define NONBLK_TYPE 1
#define SIGACT_TYPE 1
#endif
