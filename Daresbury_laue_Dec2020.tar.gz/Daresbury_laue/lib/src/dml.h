/* Declarations for DML routines */

int dml_init (int init_alloc, int inc_alloc, int rec_size);
int dml_addrec (int mindx, void * rec);
int dml_delrecs (int mindx, int (*delfun)(), void * client_data);
int dml_numrecs (int mindx);
void * dml_recpointer (int mindx, int irec);
int dml_getrec (int mindx, int irec, void * rec);
int dml_putrec (int mindx, int irec, void * rec);
void * dml_data (int mindx);
int dml_clear (int mindx);
int dml_freespace (int mindx);
int dml_free (int mindx);
void dml_freeall();
int dml_sort (int mindx, int (*compar)());
int dml_sort0 (int mindx, int (*compar)());
int dml_qsor (void * data, int nrecs, int rec_len, int (*compar)());
int dml_qsor0 (void * data, int nrecs, int rec_len, int (*compar)());
