/* MAR CCD image header. First comes a TIFF format header, then a large */
/* number of other items. Currently, processing_gui does not use the TIFF */
/* headers, and only a few of the other items */

typedef struct {
  char tiff_header[1024];
  char filler1[28];
  int header_byte_order;
  int data_byte_order;
  int header_size;
  char filler2[40];
  int total_pixels_x;
  int total_pixels_y;
  int bytes_per_pixel;
  int bytes_per_record;
  int bits_per_pixel;
  int data_type;
  int saturation;
  char filler3[20];
  int overflow_location;  /* after header or after data */
  int over_8_bits;
  int no_overflows;
  char filler4[500];
  int distance;
  int beam_x;
  int beam_y;
  int item1[4];
  int two_theta;
  int item2[3];
  int phi_start;
  int delta_start;
  int gamma_start;
  int distance_start;
  int item3[4];
  int phi_end;
  int item4[3];
  int axis_code;
  int item7[9];
  int rasterx;
  int rastery;
  char filler5[128];
  int lambda;
  char filler6[2160];
} Marccdheader;
