/*
*****************************
**   read_full_marccd_     **
*****************************

Purpose: Read a MAR CCD image file and return the image data in 
         an array. The file may have its data in any of the eight
         possible orders and may be byte swapped if needed (the default
         is assumed to  have yf moving fastest and xf 
         slowest) and is in unsigned two byte integer format without any 
         header. The number of x rasters and number of y rasters supplied
         will be checked against the values in the header.

Derived from read_full_smv_.

*/
/*-Fortran:
         CALL READ_FULL_MARCCD (IFD, IORD, NXRASTS, NYRASTS,
        +                         IVH_BAR, IXROOT, IYROOT, SPINDLE,
        +                         CTOF, RASTR, XCENF, YCENF, IMG_FULL,
        +                         MINVAL, MAXVAL, IERR)
-end*/
 
/*-Parameters:
IFD      (R)   The file descriptor (see fd)
KORD     (R)   Byte swap code, -1 to swap, otherwise 1
NXRASTS  (R)   The number of x rasters (see nxrasts)
NYRASTS  (R)   The number of y rasters (see nyrasts)
IVH_BAR  (R)   View-object handle for displaying a read progress
               bar >0 on 0 if none required (see vh_bar)
IXROOT   (R)   x root position for progress bar display if
               required (see xroot)
IYROOT   (R)   y root position for progress bar display if 
               required (see yroot)
SPINDLE  (R/W) Value of rotation angle for exposure, may be updated from header
CTOF     (R/W) Crystal-to-detector distance, may be updated from header
RASTR    (R/W) Pixel size, may be updated from header
XCENF    (R/W) X-coord of direct beam position, may be updated from header
YCENF    (R/W) Y-coord of direct beam position, may be updated from header
IORD     (R)   Code for order of the data in the image
IMG_FULL (W)   Array to hold the read data (pass as an
               integer array sufficiently large to hold the
               returned image data) (see img_full)
MINVAL   (W)   The minimum pixel value in the image (see minval)
MAXVAL   (W)   The maximum pixel value in the image (see maxval)
IERR     (W)   Returns the status from the xdl_read_full_marccd call
-end*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include "marccdheader.h"

/*-C:*/
int read_full_marccd_ (ifd, iorder, inxrasts, inyrasts, ivh_bar, ixroot, 
 iyroot, ispin, idist, irast, icen_x, icen_y, iiord, img_full, minval, maxval, 
 ierr)
/*end*/
 
int *ifd, *iorder, *inxrasts, *inyrasts, *ivh_bar, *ixroot, *iyroot, *iiord,
 *ierr;
float *ispin, *idist, *irast, *icen_x, *icen_y;
unsigned short img_full[];
                  /* Array returning the read image data. 
                     Normally called with *iiord = 1, in which case
                     the slower moving index in
                     the returned data is x going from low x to
                     high x and the faster moving index is y going 
                     from low y to high y i.e. the same order as in the
                     file. (W)*/
int *minval;      /* Returns the minimum pixel value in the image (W)*/
int *maxval;      /* Returns the maximum pixel value in the image (W)*/
{
/*-Parameters:*/
int fd;           /* The file descriptor of the opened film format 
                     file (R)*/
int order;        /* Whether or not to swap bytes of image data, 
                     +/- for no/yes. May be overridden by byte order
                     determined from image file header. (R) */
int iord;         /* Order of the data in the input film image file
                     in terms of the xf, yf coordinate system as
                     a number from 1 to 8.
                     1   +xf slow   +yf fast
                     2   +xf slow   -yf fast
                     3   -xf slow   +yf fast
                     4   -xf slow   -yf fast
                     5   +yf slow   +xf fast
                     6   +yf slow   -xf fast
                     7   -yf slow   +xf fast
                     8   -yf slow   -xf fast
                     (R)*/
int nxrasts;      /* The number of x rasters (R)*/
int nyrasts;      /* The number of y rasters (R)*/
int vh_bar;       /* View-object handle (>0) for display bar showing the
                     progress of the read, 0 if none required (R) */
int xroot;        /* The root x position for the top left of the display
                     bar area if required (R)*/
int yroot;        /* The root y position for the top left of the display
                     bar area if required (R)*/
/*end*/
/*-Doc:
Return:  =0 OK; >0 Record number where a read error occurred.
-end*/
   int i, j, k, l, nn, head_len;
   int swap;
   int irec;
   int step;
   int nrecs, nrasts;
   unsigned short *buf;
   unsigned char *cbuf;
   unsigned char tempc;
   Marccdheader header;
   char hd_len[24], value[132];
   int ir, header_xrast, header_yrast;
   float spin, dist, rast, cen_x, cen_y, header_spin, header_dist, header_rast,
    header_cen_x, header_cen_y, dif, r1, r2, r3;

   /* Initialisations */

  fd = *ifd;
  order = *iorder;
  iord = *iiord;
  nxrasts = *inxrasts;
  nyrasts = *inyrasts;
  vh_bar = *ivh_bar;
  xroot = *ixroot;
  yroot = *iyroot;
  spin = *ispin;
  dist = *idist;
  rast = (*irast)*0.001;
  cen_x = *icen_x;
  cen_y = *icen_y;

  *minval = 1000000;
  *maxval = 0;
  swap = 0;
  if (order<0) {
    swap = 1;
    order = -order;
  }
  if(order<1||order>8) 
    order=1;
  nrecs = nxrasts;
  nrasts = nyrasts;
  if (order>4) {
    nrecs = nyrasts;
    nrasts = nxrasts;
  }

/* Read header */
  lseek (fd, 0L, 0);
  head_len = sizeof(Marccdheader);
  nn = read (fd,&header,head_len);
  if (nn < head_len) {
    printf ("Error reading MAR CCD header for image file\n");
    close (fd);
    exit (-1);
  }
printf ("MAR CCD header pixels %d %d\n",header.total_pixels_x,
 header.total_pixels_y);
  if (header.total_pixels_x < 0 || header.total_pixels_x > 10000) {
    if (swap == 0)
      swap = 1;
    swab ((void *)&header.total_pixels_x,(void *)&j,4);
    header.total_pixels_x =
     (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
    swab ((void *)&header.total_pixels_y,(void *)&j,4);
    header.total_pixels_y =
     (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
    if (header.total_pixels_x < 0 || header.total_pixels_x > 10000) {
      printf ("Bad MAR CCD header for image file\n");
      close (fd);
      exit (-1);
    }
    swab ((void *)&header.rasterx,(void *)&j,4);
    header.rasterx =
     (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
    swab ((void *)&header.beam_x,(void *)&j,4);
    header.beam_x =
     (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
    swab ((void *)&header.beam_y,(void *)&j,4);
    header.beam_y =
     (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
    swab ((void *)&header.distance,(void *)&j,4);
    header.distance =
     (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
    swab ((void *)&header.distance_start,(void *)&j,4);
    header.distance_start =
     (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
    swab ((void *)&header.phi_start,(void *)&j,4);
    header.phi_start =
     (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
  }
  else {
    if (swap == 1)
      swap = 0;
  }
  header_yrast = header.total_pixels_x;            /* Image dimensions */
  header_xrast = header.total_pixels_y;
  if ((nxrasts != header_xrast) || (nyrasts != header_yrast)) {
    printf (
"Warning - dimensions in file header (%d x %d) do not agree with input (%d x %d)\n",
     header_xrast,header_yrast,nxrasts,nyrasts);
  }
  header_spin = 0.001 * header.phi_start;        /* Spindle angle */
  r1 = 0.000001 * header.rasterx;                /* Raster (pixel) size */
  if (r1 > 0.001 && r1 < 5.0)
    header_rast = r1;
  else
    header_rast = rast;
  r1 = 0.001 * header.distance;                  /* Distance */
  if (r1 < 0.001)
    r1 = 0.001 * header.distance_start;
  if (r1 > 0.0)
    header_dist = r1;
  else
    header_dist = dist;
  header_cen_x = 0.001 * header.beam_y;              /* Beam center (slow) */
  header_cen_y = 0.001 * header.beam_x;              /* Beam center (fast) */
  dif = fabsf (header_spin - spin);
  if (dif > 0.01)
    printf (
"Warning - spindle angle %.3f in header does not agree with expected value %.3f\n",
     header_spin,spin);
  dif = fabsf (header_rast - rast);
  if (dif > 0.001)
    printf (
"Warning - pixel size %.4f in header does not agree with expected value %.4f\n",
     header_rast,rast);
  dif = fabsf (header_dist - dist);
  if (dif > 0.1)
    printf (
"Warning - distance %.2f in header does not agree with expected value %.2f\n",
     header_dist,dist);
  r1 = header_xrast;
  r2 = header_yrast;
  switch (iord) {
    case 2:
      header_cen_y = r2 - header_cen_y;
      break;
    case 3:
      header_cen_x = r1 - header_cen_x;
      break;
    case 4:
      header_cen_x = r1 - header_cen_x;
      header_cen_y = r2 - header_cen_y;
      break;
    case 5:
      r3 = header_cen_x;
      header_cen_x = header_cen_y;
      header_cen_y = r3;
      break;
    case 6:
      r3 = r1 - header_cen_x;
      header_cen_x = header_cen_y;
      header_cen_y = r3;
      break;
    case 7:
      r3 = header_cen_x;
      header_cen_x = r2 - header_cen_y;
      header_cen_y = r3;
      break;
    case 8:
      r3 = r1 - header_cen_x;
      header_cen_x = r2 - header_cen_y;
      header_cen_y = r3;
  }
  r1 = header_cen_y;
  r2 = header_cen_x;
  dif = fabsf (r1 - cen_x);
  dif += fabsf (r2 - cen_y);
  if (dif > 0.1)
    printf (
"Warning - beam center %.2f %.2f in header does not agree with expected value %.2f %.2f\n",
     r1,r2,cen_x,cen_y);

  if (vh_bar>0) xdl_progress_bar (vh_bar, xroot, yroot, "Read progress", 0, 
   120, nrecs, 2, 5);
   
   /* Read data */

   buf = (unsigned short *) malloc(nrasts*sizeof(unsigned short));
   if (buf==0) {
     *ierr = -1;
     return -1;
   }
   cbuf = (unsigned char *) buf;
   irec = 1;
   for (ir=0;ir<nrecs;++ir) {
     i = read (fd, buf, 2*nrasts);
     if (i!=2*nrasts) 
       goto tidy;
     switch (order) {
         case 1:
            j = ir*nrasts;
            step = 1;
            break;
         case 2:
            j = (ir+1)*nrasts - 1;
            step = -1;
            break;
         case 3:
            j = (nrecs-ir-1)*nrasts;
            step = 1;
            break;
         case 4:
            j = (nrecs-ir)*nrasts - 1;
            step = -1;
            break;
         case 5:
            j = ir;
            step = nrecs;
            break;
         case 6:
            j = nrecs - 1 - ir;
            step = nrecs;
            break;
         case 7:
            j = (nrasts-1)*nrecs + ir;
            step = -nrecs;
            break;
         case 8:
            j = nrasts*nrecs - 1 - ir;
            step = -nrecs;
            break;
      }
      if (swap)
      {
         l=0;
         for (k=0;k<nrasts;++k)
         {
             tempc = cbuf[l];
             cbuf[l] = cbuf[l+1];
             cbuf[l+1] = tempc;
             l += 2;
         }
      }
      for (k=0;k<nrasts;++k)
      {
          img_full[j] = buf[k];
          if (buf[k]<*minval) *minval = buf[k];
          if (buf[k]>*maxval) *maxval = buf[k];
          j += step;
      }
      if (vh_bar>0) xdl_progress_bar_value (vh_bar, ir+1);
      irec++;
   }
   irec = 0;   
   
   /* Tidy up */

   tidy:
   free (buf);
   if (vh_bar>0) xdl_delete_view_object (vh_bar);
   *ierr = irec;
   return irec;
}
