/* KDM declarations */


int kdm_init (int maxnum_sets, int maxnum_subsets, char * nums_nam, int lens,
              char * numss_nam, int lenss, char * snam, int lensnam,
              char * ssnam, int lenssnam, int * kdx);
int kdm_numpars (int kdx, int * nump);
int kdm_parname (int kdx, int ipar, char * name, int maxn);
int kdm_define_int (int kdx, char * name, int lenn, int minl,
                    int ityp, int std, int nvals, int * i_default, int i_min, 
                    int i_max, int chk_typ, int (*chk_func)());
int kdm_define_float (int kdx, char * name, int lenn, int minl,
                      int ityp, int std, int nvals, float *f_default, 
                      float f_min, float f_max, int chk_typ, 
                      int (*chk_func)(), int nd, int default_nd);
int kdm_define_str (int kdx, char * name, int lenn, int minl,
                    int ityp, int std, int maxlen, char * s_default, int lend,
                    char ** strings, int nums, int lens, int chk_typ, 
                    int match, int (*chk_func)());
int kdm_define_varr   (int kdx, char * name, int lenn, int minl,
                      int ityp, int std, int nvals, int nvals_min, 
                      int *i_default, float *f_default, int *irtyp,
                      int chk_typ, int (*chk_func)(), 
                      int *nd, int *default_nd, int npr_dflt);
int kdm_set_alias (int kdx, char * keyword, int lenk, char * alias,
                   int lena, int minlen);
int kdm_printname (int kdx, char * keyword, int lenk, int use_alias);
int kdm_checkpar (int kdx, char * keyword, int lenk, int iset, int isubset,
                  int iss, char * name, int maxn, int * ityp, int * nvals,
                  int *ipar);
int kdm_reset (int kdx, char * keyword, int lenk, int iset, int isubset,
               char * errstr, int maxe);
int kdm_setvalue (int kdx, char * keyword, int lenk, int iset, int isubset,  
                  char * valstr, int lenv, int * ival, float * fval, 
                  int iopt, char * errstr, int maxe);
int kdm_getvalue (int kdx, char * keyword, int lenk, int iset, int isubset, 
                  int maxv, char * valstr,  float * fval, int * nd, 
                  int * ival, int * num_inp, int * istat, int * ityp, 
                  char * errstr, int maxe);
int kdm_getvalstr (int kdx, char * keyword, int lenk, int iset, int isubset, 
                  int maxv, char * valstr, int *istat, int *ityp, 
                  char * errstr, int maxe);
int kdm_output (int kdx, char * keyword, int lenk, int ichanged, 
                int ireduce, int ns, int * nss, char * outstr, int maxo,
                void (*op_func)(), char * errstr,  int maxe);
int kdm_ch_reset (int kdx, int ichan);
int kdm_any_ch (int kdx, int ichan);
int kdm_changed (int kdx, char * keyword, int lenk, int ichan, int iset,
                 int isubset);
void kdm_strval (char * valstr, int maxl);
void kdm_set_chkerr (char * errstr, int lerr);
int kdm_next_field (char * text, int lent, char * sep, int * p1, int *p2, 
                    int *lc);
int kdm_next_int (char * text, int lent, char * sep, int * ival, int *lc);
int kdm_next_float (char * text, int lent, char * sep, float * fval, 
                    int *nd, int *lc);
int kdm_readline (FILE * fp_in, int * indirect, char * line, int maxlen);
int kdm_readstr (char * line, int maxlen, int *indirect, int *iflag);
int kdm_parsekdm (int kdx, char * line, int (*chk_func)(),
                  char * badtok, int maxb, char * errstr, int maxe);
int kdm_parseitem (char * str, char * keyword, int * iset, int * isubset,
                   int * iss);
int kdm_writekdm (int kdx, FILE * fp, int ioptyp, int ichanged);
void kdm_opfun();
void kdm_copy_chars();
void kdm_addstr();
void kdm_addout();
int kdm_blank_string();
void kdm_upc();
void kdm_lwc();
int kdm_ncasecmp();
void kdm_chop_end_blanks (char * str);
