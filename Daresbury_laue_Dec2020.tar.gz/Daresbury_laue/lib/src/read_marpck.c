/*
*****************************
**   read_full_marpck_     **
*****************************

Purpose: Read a packed MAR image plate file and return the image data in 
         an array. The file may have its data in any of the eight
         possible orders and may be byte swapped if needed (the default
         is assumed to  have yf moving fastest and xf slowest). Input data
         are 2-byte unsigned integers plus overflow info. Output data are
         either 2-byte unsigned (overflows set to 65535) or 4-byte (signed),
         depending on the value of IFTYPE. The number of x rasters and 
         number of y rasters supplied will be checked against the header.

Derived from read_full_smv_.

*/
/*-Fortran:
         CALL READ_FULL_MARPCK (IFD, IFTYPE, KORD, NXRASTS, NYRASTS,
        +                         IVH_BAR, IXROOT, IYROOT, IORD, IMG_FULL,
        +                         MINVAL, MAXVAL, IERR)
-end*/
 
/*-Parameters:
IFD      (R)   The file descriptor (see fd)
KORD     (R)   Byte swap code, -1 to swap, otherwise 1
IFTYPE   (R)   Type of output data, either 2 (2-byte unsigned) or 5 (4-byte)
NXRASTS  (R/W) The number of x rasters, may be updated from header
NYRASTS  (R/W) The number of y rasters, may be updated from header
IVH_BAR  (R)   View-object handle for displaying a read progress
               bar >0 on 0 if none required (see vh_bar)
IXROOT   (R)   x root position for progress bar display if
               required (see xroot)
IYROOT   (R)   y root position for progress bar display if 
               required (see yroot)
IORD     (R)   Code for order of the data in the image
IMG_FULL (W)   Array to hold the read data (pass as an
               integer array sufficiently large to hold the
               returned image data) (see img_full)
MINVAL   (W)   The minimum pixel value in the image (see minval)
MAXVAL   (W)   The maximum pixel value in the image (see maxval)
IERR     (W)   Returns the status from the xdl_read_full_tiff call
-end*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "marimageheader.h"

static const int setbits[33] =
                         {0x00000000, 0x00000001, 0x00000003, 0x00000007,
                          0x0000000F, 0x0000001F, 0x0000003F, 0x0000007F,
                          0x000000FF, 0x000001FF, 0x000003FF, 0x000007FF,
                          0x00000FFF, 0x00001FFF, 0x00003FFF, 0x00007FFF,
                          0x0000FFFF, 0x0001FFFF, 0x0003FFFF, 0x0007FFFF,
                          0x000FFFFF, 0x001FFFFF, 0x003FFFFF, 0x007FFFFF,
                          0x00FFFFFF, 0x01FFFFFF, 0x03FFFFFF, 0x07FFFFFF,
                          0x0FFFFFFF, 0x1FFFFFFF, 0x3FFFFFFF, 0x7FFFFFFF,
                          0xFFFFFFFF};

#define shift_left(x, n)  (((x) & setbits[32 - (n)]) << (n))
#define shift_right(x, n) (((x) >> (n)) & setbits[32 - (n)])

int convert_marheader(Marimageheader *v, Marimageheader *n);
void unpack_word(int fd, int x, int y, short int *img);
void v2unpack_word(int fd, int x, int y, short int *img);

/*-C:*/
int read_full_marpck_ (ifd, idtype, iorder, inxrasts, inyrasts, ivh_bar, 
 ixroot, iyroot, iiord, img_full, minval, maxval, ierr)
/*end*/
 
int *ifd, *idtype, *iorder, *inxrasts, *inyrasts, *ivh_bar, *ixroot, *iyroot, 
 *iiord, *ierr;
int img_full[];
                  /* Array returning the read image data. 
                     Normally called with *iiord = 1 or -1, in which case
                     the slower moving index in
                     the returned data is x going from low x to
                     high x and the faster moving index is y going 
                     from low y to high y i.e. the same order as in the
                     file. (W)*/
int *minval;      /* Returns the minimum pixel value in the image (W)*/
int *maxval;      /* Returns the maximum pixel value in the image (W)*/
{
/*-Parameters:*/
int fd;           /* The file descriptor of the opened image
                     file (R)*/
int data_type;    /* Type of output data, 2 for 2-byte uns, 5 for 4-byte */
int order;        /* Whether or not to swap bytes of image data, 
                     +/- for no/yes. May be overridden by byte order
                     determined from image file header. (R) */
int iord;         /* Order of the data in the input film image file
                     in terms of the xf, yf coordinate system as
                     a number from 1 to 8.
                     1   +xf slow   +yf fast
                     2   +xf slow   -yf fast
                     3   -xf slow   +yf fast
                     4   -xf slow   -yf fast
                     5   +yf slow   +xf fast
                     6   +yf slow   -xf fast
                     7   -yf slow   +xf fast
                     8   -yf slow   -xf fast
                     (R)*/
int nxrasts;      /* The number of x rasters (R/W)*/
int nyrasts;      /* The number of y rasters (R/W)*/
int vh_bar;       /* View-object handle (>0) for display bar showing the
                     progress of the read, 0 if none required (R) */
int xroot;        /* The root x position for the top left of the display
                     bar area if required (R)*/
int yroot;        /* The root y position for the top left of the display
                     bar area if required (R)*/
/*end*/
/*-Doc:
Return:  =0 OK; >0 Record number where a read error occurred.
-end*/
   int i, j, k, l, n, jj, nn, i1, i2, iu, found;
   int swap;
   int irec;
   int step;
   int nrecs, nrasts, itemp;
   int *i4ptr;
   long int offset;
   unsigned short i2temp, i2temp2;
   unsigned short *i2ptr, *i2ptr2, *buf;
   unsigned char tempc, *cbuf;
   char chold[512];
   char *header, *tiff_temp, *cp, *cptr, *cptr2;
   Marimageheader iheader, jheader;
   Marimageoflow *oflow_pix;
   int ir, header_bytes, packed, filesize, overflows;
   struct stat filestat;

   /* Initialisations */

  fd = *ifd;
  fstat (fd, &filestat);
  filesize = filestat.st_size;
  data_type = *idtype;
  order = *iorder;
  nxrasts = *inxrasts;
  nyrasts = *inyrasts;
  vh_bar = *ivh_bar;
  xroot = *ixroot;
  yroot = *iyroot;
  iord = *iiord;

   *minval = 1000000;
   *maxval = 0;
   swap = 0;
   if (order<0)
   {
      swap = 1;
      order = -order;
   }
   if(order<1||order>8) order=1;
   nrecs = nxrasts;
   nrasts = nyrasts;
   if (order>4) {
     nrecs = nyrasts;
     nrasts = nxrasts;
   }

/* Read header */
  lseek (fd, 0L, 0);
  nn = read (fd,&jheader,sizeof(Marimageheader));
  if (nn <= 0) {
    fprintf (stderr,"Cannot read header from image file.\n");
    *ierr = -1;
    return -1;
  }
  nn = convert_marheader(&jheader,&iheader);
  if (iheader.total_pixels_x == 1234) {                /* Packed format */
    packed = 1;
    header_bytes = 4096;
    fprintf (stderr,
     "Read header for packed MAR IP image OK.\n");
    nrecs = iheader.total_pixels_y;
    nrasts = nrecs;
    iheader.main_part.oldmar.overflow_pixels =
     iheader.main_part.newmar.no_overflows;
  }
  else {
    packed = 0;                                   /* Unpacked format */
    if ( 
     (iheader.total_pixels_x == 1200) || (iheader.total_pixels_x == 1600) ||
     (iheader.total_pixels_x == 1800) || (iheader.total_pixels_x == 2000) ||
     (iheader.total_pixels_x == 2300) || (iheader.total_pixels_x == 2400) ||
     (iheader.total_pixels_x == 3000) || (iheader.total_pixels_x == 3450)) {
      fprintf (stderr,
       "Read header for unpacked MAR IP image OK.\n");
    }
    else {
      fprintf (stderr,"MAR header specifies invalid size %d x %d.\n",
       iheader.total_pixels_x, iheader.total_pixels_y);
      *ierr = -1;
      return -1;
    }
    nrasts = iheader.total_pixels_x;
    nrecs = iheader.total_pixels_y;
    header_bytes = 2 * iheader.total_pixels_x;
  }
  overflows = iheader.main_part.oldmar.overflow_pixels;
  
  if (order > 4) {
    if ((nrecs != nyrasts) || (nrasts != nxrasts))
      fprintf (stderr,
"Warning, input and header dimensions do not match:\n   %d x %d vs. %d x %d\n",
       nxrasts,nyrasts,nrasts,nrecs);
  }
  else {
    if ((nrecs != nxrasts) || (nrasts != nyrasts))
      fprintf (stderr,
"Warning, input and header dimensions do not match:\n   %d x %d vs. %d x %d\n",
       nxrasts,nyrasts,nrecs,nrasts);
  }
                                      /* Check for packed data with old-style */
                                      /* header - determine from file size */
  j = 2 * iheader.total_pixels_x * iheader.total_pixels_y + 
   sizeof(Marimageheader);
  if (filesize < j)
    packed = 1;

  offset = header_bytes;                /* Go to end of header */
  lseek (fd,offset,SEEK_SET);
  n = nrecs * nrasts;

  /* Read overflows, if any */
  if (overflows > 0) {
    oflow_pix = (Marimageoflow *)malloc(overflows*sizeof(Marimageoflow));
    if (packed) {                   /* Packed MAR, overflows before data */
      nn = read (fd,oflow_pix,(overflows*sizeof(Marimageoflow)));
      offset = header_bytes + (overflows*8);
      lseek (fd,offset,SEEK_SET);           /* Go to start of data */
    }
    else {                          /* Unpacked, overflows after data */
      offset = header_bytes + (n * sizeof (unsigned short int));
      lseek (fd,offset,SEEK_SET);
      nn = read (fd,oflow_pix,(overflows*sizeof(Marimageoflow)));
      offset = header_bytes;                /* Go to start of data */
      lseek (fd,offset,SEEK_SET);
    }
    if (swap) {                       /* Swap overflows if necessary */
      i4ptr = (int *)oflow_pix;
      for (i = 0; i < 2*overflows; i++) {
        swab ((void *)i4ptr, (void *)&j, 4);
        *i4ptr = (( (j)&0xFFFF) << 16) | (( (j)&0xFFFF0000) >> 16);
      }
    }
  }

  if (vh_bar>0) xdl_progress_bar (vh_bar, xroot, yroot, "Read progress", 0, 
                                   120, nrecs, 2, 5);
   
   /* Read data */

  buf = (unsigned short *) malloc(n*sizeof(unsigned short));
  if (buf==0) {
    *ierr = -1;
    return -1;
  }
  if (packed) {                               /* Packed data */
    cptr = 0;
    while (cptr == (char *)NULL) {
      nn = read (fd, chold, 512);
      for (j = 0; j < 512; j++) {
        if (chold[j] == 'C') {
          cptr = &chold[j];
          break;
        }
      }
      if (cptr != (char *)NULL) {
        if ((512 - (cptr - chold)) < 64) {
          offset = offset + (cptr - 4 - chold);
          i = lseek (fd, offset, SEEK_SET); 
          nn = read (fd, chold, 512);
          for (j = 0; j < 512; j++) {
            if (chold[j] == 'C') {
              cptr = &chold[j];
              break;
            }
          }
        }
        if (strncmp (cptr,"CCP4 packed image",17) != 0) {
          fprintf (stderr," *** Bad MAR image file\n");
          *ierr = -1;
          return -1;
        }
        cptr--;
        if (sscanf(cptr, PACKIDENTIFIER, &i1, &i2) == 2) {
          if ((i1 * i2) != n) {
            fprintf (stderr," *** Bad MAR image file\n");
            *ierr = -1;
            return -1;
          }
          cptr++;
          cptr2 = strstr (cptr,"\n");
          offset += (cptr2 + 1 - chold);
          i = lseek (fd, offset, SEEK_SET); 
          unpack_word (fd, i1, i2, (short int *)buf);
        }
        else if (sscanf(cptr, V2IDENTIFIER, &i1, &i2) == 2) {
          if ((i1 * i2) != n) {
            fprintf (stderr," *** Bad MAR image file\n");
            *ierr = -1;
            return -1;
          }
          cptr++;
          cptr2 = strstr (cptr,"\n");
          offset += (cptr2 + 1 - chold);
          i = lseek (fd, offset, SEEK_SET); 
          v2unpack_word (fd, i1, i2, (short int *)buf);
        }
        else {
          fprintf (stderr," *** Bad MAR image file\n");
          *ierr = -1;
          return -1;
        }
      }
    }
  }
  else {                                   /* Unpacked */
    nn = read (fd, buf, n);
  }
  i2ptr2 = buf;                     /* Transfer data to output array */
  i2ptr = (unsigned short int *)img_full;
  irec = 1;
  for (ir = 0; ir < nrecs; ir++) {
    switch (order) {
      case 1:
        j = ir*nrasts;
        step = 1;
        break;
      case 2:
        j = (ir+1)*nrasts - 1;
        step = -1;
        break;
      case 3:
        j = (nrecs-ir-1)*nrasts;
        step = 1;
        break;
      case 4:
        j = (nrecs-ir)*nrasts - 1;
        step = -1;
        break;
      case 5:
        j = ir;
        step = nrecs;
        break;
      case 6:
        j = nrecs - 1 - ir;
        step = nrecs;
        break;
      case 7:
        j = (nrasts-1)*nrecs + ir;
        step = -nrecs;
        break;
      case 8:
        j = nrasts*nrecs - 1 - ir;
        step = -nrecs;
        break;
    }
    for (k = 0; k < nrasts; k++) {
      if (swap) {
        swab ((void *)i2ptr2,(void *)&i2temp,2);
        *i2ptr2 = i2temp;
      }
      if (data_type == 5) {           /* 4-byte output, use overflow info */
        img_full[j] = *i2ptr2;
        if (overflows > 0) {     
          if (*i2ptr2 > 65534) {
            iu = (ir * nrasts) + k;
            for (i1 = 0; i1 < overflows; i1++) {
              if (iu == oflow_pix[i1].location) {
                img_full[j] = oflow_pix[i1].value;
                break;
              }
            }
          }
        }
        itemp = img_full[j];
      }
      else {                          /* 2-byte output, ignore overflow info */
        i2ptr = (unsigned short int *)img_full + j;
        *i2ptr = *i2ptr2;
        itemp = *i2ptr2;
      }
      if (itemp < *minval) 
        *minval = itemp;
      if (itemp > *maxval) 
        *maxval = itemp;
      i2ptr2++;
      j += step;
    }
    if (vh_bar>0) 
       xdl_progress_bar_value (vh_bar, ir+1);
    irec++;
  }
  irec = 0;
   
   /* Tidy up */

  tidy:
  free (buf);
  if (vh_bar>0) 
    xdl_delete_view_object (vh_bar);
  if (order>4) {
    *inxrasts = nrasts;
    *inyrasts = nrecs;
  }
  else {
    *inxrasts = nrecs;
    *inyrasts = nrasts;
  }
  *ierr = irec;
  return irec;
}

#define CVT_VAX_F		1
#define CVT_IEEE_S		5
#define CVT_BIG_ENDIAN_IEEE_S	8
#define CVT_IBM_SHORT		11

/* macro to swap bytes for 4-byte integer */
#define icvt(name)	swab(&v->name, &n->name, 4), swaw(&n->name) 

void get_cvt_args (float *r1, float *r2, float *r3, float *r4, int *cvt_arg_in,
 int *cvt_arg_out);

int
convert_marheader(v, n)
Marimageheader *v, *n;
{
  extern swaw();
  int swap_needed;
  int cvt_arg_in, cvt_arg_out, ret_stat;
  float rtemp1, rtemp2, rtemp3, rtemp4;

  memcpy (n,v,sizeof(Marimageheader));
  swap_needed = 0;
  if (v->total_pixels_x < 1000 || v->total_pixels_x > 5000) {
    icvt(total_pixels_x);
    swap_needed = 1;
  }
  else
    n->total_pixels_x = v->total_pixels_x;

  if (n->total_pixels_x == 1234) {   /* New MAR .pck format */
    if (swap_needed) {
      icvt(total_pixels_y);                      /* Swap integers */
      icvt(main_part.newmar.no_overflows);
      icvt(main_part.newmar.image_format);
      icvt(main_part.newmar.collection_mode);
      icvt(main_part.newmar.total_pixels);
      icvt(main_part.newmar.rasterx);
      icvt(main_part.newmar.rastery);
      icvt(main_part.newmar.lambda);
      icvt(main_part.newmar.distance);
      icvt(main_part.newmar.phi_start);
      icvt(main_part.newmar.phi_end);
      icvt(main_part.newmar.omega);
    }
    else {
      n->total_pixels_y = v->total_pixels_y;
      n->main_part.newmar.no_overflows = v->main_part.newmar.no_overflows;
      n->main_part.newmar.image_format = v->main_part.newmar.image_format;
      n->main_part.newmar.collection_mode = v->main_part.newmar.collection_mode;
      n->main_part.newmar.total_pixels = v->main_part.newmar.total_pixels;
      n->main_part.newmar.rasterx = v->main_part.newmar.rasterx;
      n->main_part.newmar.rastery = v->main_part.newmar.rastery;
      n->main_part.newmar.lambda = v->main_part.newmar.lambda;
      n->main_part.newmar.distance = v->main_part.newmar.distance;
      n->main_part.newmar.phi_start = v->main_part.newmar.phi_start;
      n->main_part.newmar.phi_end = v->main_part.newmar.phi_end;
      n->main_part.newmar.omega = v->main_part.newmar.omega;
    }
  }
  else {                          /* Old MAR format */
    if (swap_needed) {
      icvt(total_pixels_y);                      /* Swap integers */
      icvt(main_part.oldmar.lrecl);
      icvt(main_part.oldmar.max_rec);
      icvt(main_part.oldmar.overflow_pixels);
      icvt(main_part.oldmar.overflow_records);
      icvt(main_part.oldmar.counts_per_sec_start);
      icvt(main_part.oldmar.counts_per_sec_end);
      icvt(main_part.oldmar.exposure_time_sec);
      icvt(main_part.oldmar.programmed_exp_time_units);
    }
    else {
      n->total_pixels_y = v->total_pixels_y;
      n->main_part.oldmar.lrecl = v->main_part.oldmar.lrecl;
      n->main_part.oldmar.max_rec = v->main_part.oldmar.max_rec;
      n->main_part.oldmar.overflow_pixels = v->main_part.oldmar.overflow_pixels;
      n->main_part.oldmar.overflow_records = 
       v->main_part.oldmar.overflow_records;
      n->main_part.oldmar.counts_per_sec_start = 
       v->main_part.oldmar.counts_per_sec_start;
      n->main_part.oldmar.counts_per_sec_end = 
       v->main_part.oldmar.counts_per_sec_end;
      n->main_part.oldmar.exposure_time_sec = 
       v->main_part.oldmar.exposure_time_sec;
      n->main_part.oldmar.programmed_exp_time_units = 
       v->main_part.oldmar.programmed_exp_time_units;
    }
    rtemp1 = v->main_part.oldmar.p_r;
    rtemp2 = v->main_part.oldmar.centre_x;
    rtemp3 = v->main_part.oldmar.lambda;
    rtemp4 = v->main_part.oldmar.phi_end;
    get_cvt_args (&rtemp1, &rtemp2, &rtemp3, &rtemp4, &cvt_arg_in, 
     &cvt_arg_out);
/*  printf ("cvt_args %d %d\n",cvt_arg_in,cvt_arg_out); */
    if (cvt_arg_in != cvt_arg_out) {                     /* Convert reals */
      ret_stat = cvt_ftof(&v->main_part.oldmar.programmed_exposure_time,
       cvt_arg_in, &n->main_part.oldmar.programmed_exposure_time, cvt_arg_out,
       0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.r_min, cvt_arg_in,
       &n->main_part.oldmar.r_min, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.r_max, cvt_arg_in,
       &n->main_part.oldmar.r_max, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.p_r, cvt_arg_in,
       &n->main_part.oldmar.p_r, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.p_l, cvt_arg_in,
       &n->main_part.oldmar.p_l, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.p_x, cvt_arg_in,
       &n->main_part.oldmar.p_x, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.p_y, cvt_arg_in,
       &n->main_part.oldmar.p_y, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.centre_x, cvt_arg_in,
       &n->main_part.oldmar.centre_x, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.centre_y, cvt_arg_in,
       &n->main_part.oldmar.centre_y, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.lambda, cvt_arg_in,
       &n->main_part.oldmar.lambda, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.distance, cvt_arg_in,
       &n->main_part.oldmar.distance, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.phi_start, cvt_arg_in,
       &n->main_part.oldmar.phi_start, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.phi_end, cvt_arg_in,
       &n->main_part.oldmar.phi_end, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.omega, cvt_arg_in,
       &n->main_part.oldmar.omega, cvt_arg_out, 0);
      ret_stat = cvt_ftof(&v->main_part.oldmar.multiplier, cvt_arg_in,
       &n->main_part.oldmar.multiplier, cvt_arg_out, 0);
    }
    strncpy( n->main_part.oldmar.scanning_date_time, 
     v->main_part.oldmar.scanning_date_time, 24);
  }
  return (swap_needed);
}

/* swap the two 16-bit halves of a 32-bit word */
swaw(w)
int * w;
{
	int t;
	t = (( (*w)&0xFFFF) << 16 ) | (( (*w)&0xFFFF0000) >> 16);
	*w = t;
	return t;
}

/* Find out proper codes for conversion of reals */
/*
 * Require that the 4 test values, when converted, are all in reasonable
 * ranges (0 is reasonable), and at least one of them is non-zero. This
 * is to deal with the fact that some values are often missing, i.e. 0,
 * but we hope not all of them.
 */
void get_cvt_args (rtest1, rtest2, rtest3, rtest4, cvt_arg_in, cvt_arg_out)
float *rtest1, *rtest2, *rtest3, *rtest4;
int *cvt_arg_in, *cvt_arg_out;
{
  float rtemp1, rtemp2, rtemp3, rtemp4; 
  int ret_stat;
  char buf[120];

  *cvt_arg_in = 0;
  *cvt_arg_out = 0;

  rtemp1 = *rtest1;
  rtemp2 = *rtest2;
  rtemp3 = *rtest3;
  rtemp4 = *rtest4;
/* printf ("get_cvt_args initial rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 *  rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) 
    return;

  ret_stat = cvt_ftof (rtest1, CVT_VAX_F, &rtemp1, CVT_BIG_ENDIAN_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest2, CVT_VAX_F, &rtemp2, CVT_BIG_ENDIAN_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest3, CVT_VAX_F, &rtemp3, CVT_BIG_ENDIAN_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest4, CVT_VAX_F, &rtemp4, CVT_BIG_ENDIAN_IEEE_S, 0);
/* printf (
 * "get_cvt_args VAX to BIG_END rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 * rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) {
    *cvt_arg_in = CVT_VAX_F;
    *cvt_arg_out = CVT_BIG_ENDIAN_IEEE_S;
    return;
  }

  ret_stat = cvt_ftof (rtest1, CVT_VAX_F, &rtemp1, CVT_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest2, CVT_VAX_F, &rtemp2, CVT_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest3, CVT_VAX_F, &rtemp3, CVT_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest4, CVT_VAX_F, &rtemp4, CVT_IEEE_S, 0);
/* printf ("get_cvt_args VAX to IEEE rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 * rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) {
    *cvt_arg_in = CVT_VAX_F;
    *cvt_arg_out = CVT_IEEE_S;
    return;
  }

  ret_stat = cvt_ftof (rtest1, CVT_VAX_F, &rtemp1, CVT_IBM_SHORT, 0);
  ret_stat = cvt_ftof (rtest2, CVT_VAX_F, &rtemp2, CVT_IBM_SHORT, 0);
  ret_stat = cvt_ftof (rtest3, CVT_VAX_F, &rtemp3, CVT_IBM_SHORT, 0);
  ret_stat = cvt_ftof (rtest4, CVT_VAX_F, &rtemp4, CVT_IBM_SHORT, 0);
/* printf ("get_cvt_args VAX to IBM rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 * rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) {
    *cvt_arg_in = CVT_VAX_F;
    *cvt_arg_out = CVT_IBM_SHORT;
    return;
  }

  ret_stat = cvt_ftof (rtest1, CVT_IEEE_S, &rtemp1, CVT_BIG_ENDIAN_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest2, CVT_IEEE_S, &rtemp2, CVT_BIG_ENDIAN_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest3, CVT_IEEE_S, &rtemp3, CVT_BIG_ENDIAN_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest4, CVT_IEEE_S, &rtemp4, CVT_BIG_ENDIAN_IEEE_S, 0);
/* printf (
 *  "get_cvt_args IEEE to BIG_END rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 *  rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) {
    *cvt_arg_in = CVT_IEEE_S;
    *cvt_arg_out = CVT_BIG_ENDIAN_IEEE_S;
    return;
  }

  ret_stat = cvt_ftof (rtest1, CVT_IEEE_S, &rtemp1, CVT_IBM_SHORT, 0);
  ret_stat = cvt_ftof (rtest2, CVT_IEEE_S, &rtemp2, CVT_IBM_SHORT, 0);
  ret_stat = cvt_ftof (rtest3, CVT_IEEE_S, &rtemp3, CVT_IBM_SHORT, 0);
  ret_stat = cvt_ftof (rtest4, CVT_IEEE_S, &rtemp4, CVT_IBM_SHORT, 0);
/* printf ("get_cvt_args IEEE to IBM rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 * rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) {
    *cvt_arg_in = CVT_IEEE_S;
    *cvt_arg_out = CVT_IBM_SHORT;
    return;
  }

  ret_stat = cvt_ftof (rtest1, CVT_IEEE_S, &rtemp1, CVT_VAX_F, 0);
  ret_stat = cvt_ftof (rtest2, CVT_IEEE_S, &rtemp2, CVT_VAX_F, 0);
  ret_stat = cvt_ftof (rtest3, CVT_IEEE_S, &rtemp3, CVT_VAX_F, 0);
  ret_stat = cvt_ftof (rtest4, CVT_IEEE_S, &rtemp4, CVT_VAX_F, 0);
/* printf ("get_cvt_args IEEE to VAX rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 * rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) {
    *cvt_arg_in = CVT_IEEE_S;
    *cvt_arg_out = CVT_VAX_F;
    return;
  }

  ret_stat = cvt_ftof (rtest1, CVT_BIG_ENDIAN_IEEE_S, &rtemp1, CVT_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest2, CVT_BIG_ENDIAN_IEEE_S, &rtemp2, CVT_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest3, CVT_BIG_ENDIAN_IEEE_S, &rtemp3, CVT_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest4, CVT_BIG_ENDIAN_IEEE_S, &rtemp4, CVT_IEEE_S, 0);
/* printf (
 * "get_cvt_args BIG_END to IEEE rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 * rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) {
    *cvt_arg_in = CVT_BIG_ENDIAN_IEEE_S;
    *cvt_arg_out = CVT_IEEE_S;
    return;
  }

  ret_stat = cvt_ftof (rtest1, CVT_BIG_ENDIAN_IEEE_S, &rtemp1, CVT_VAX_F, 0);
  ret_stat = cvt_ftof (rtest2, CVT_BIG_ENDIAN_IEEE_S, &rtemp2, CVT_VAX_F, 0);
  ret_stat = cvt_ftof (rtest3, CVT_BIG_ENDIAN_IEEE_S, &rtemp3, CVT_VAX_F, 0);
  ret_stat = cvt_ftof (rtest4, CVT_BIG_ENDIAN_IEEE_S, &rtemp4, CVT_VAX_F, 0);
/* printf (
 * "get_cvt_args BIG_END to VAX rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 * rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) {
    *cvt_arg_in = CVT_BIG_ENDIAN_IEEE_S;
    *cvt_arg_out = CVT_VAX_F;
    return;
  }

  ret_stat = cvt_ftof (rtest1, CVT_BIG_ENDIAN_IEEE_S, &rtemp1, CVT_IBM_SHORT, 
   0);
  ret_stat = cvt_ftof (rtest2, CVT_BIG_ENDIAN_IEEE_S, &rtemp2, CVT_IBM_SHORT, 
   0);
  ret_stat = cvt_ftof (rtest3, CVT_BIG_ENDIAN_IEEE_S, &rtemp3, CVT_IBM_SHORT, 
   0);
  ret_stat = cvt_ftof (rtest4, CVT_BIG_ENDIAN_IEEE_S, &rtemp4, CVT_IBM_SHORT, 
   0);
/* printf (
 * "get_cvt_args BIG_END to IBM rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 * rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) {
    *cvt_arg_in = CVT_BIG_ENDIAN_IEEE_S;
    *cvt_arg_out = CVT_IBM_SHORT;
    return;
  }

  ret_stat = cvt_ftof (rtest1, CVT_IBM_SHORT, &rtemp1, CVT_BIG_ENDIAN_IEEE_S, 
   0);
  ret_stat = cvt_ftof (rtest2, CVT_IBM_SHORT, &rtemp2, CVT_BIG_ENDIAN_IEEE_S, 
   0);
  ret_stat = cvt_ftof (rtest3, CVT_IBM_SHORT, &rtemp3, CVT_BIG_ENDIAN_IEEE_S, 
   0);
  ret_stat = cvt_ftof (rtest4, CVT_IBM_SHORT, &rtemp4, CVT_BIG_ENDIAN_IEEE_S, 
   0);
/* printf (
 * "get_cvt_args IBM to BIG_END rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 * rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) {
    *cvt_arg_in = CVT_IBM_SHORT;
    *cvt_arg_out = CVT_BIG_ENDIAN_IEEE_S;
    return;
  }

  ret_stat = cvt_ftof (rtest1, CVT_IBM_SHORT, &rtemp1, CVT_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest2, CVT_IBM_SHORT, &rtemp2, CVT_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest3, CVT_IBM_SHORT, &rtemp3, CVT_IEEE_S, 0);
  ret_stat = cvt_ftof (rtest4, CVT_IBM_SHORT, &rtemp4, CVT_IEEE_S, 0);
/* printf ("get_cvt_args IBM to IEEE rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 * rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) {
    *cvt_arg_in = CVT_IBM_SHORT;
    *cvt_arg_out = CVT_IEEE_S;
    return;
  }

  ret_stat = cvt_ftof (rtest1, CVT_IBM_SHORT, &rtemp1, CVT_VAX_F, 0);
  ret_stat = cvt_ftof (rtest2, CVT_IBM_SHORT, &rtemp2, CVT_VAX_F, 0);
  ret_stat = cvt_ftof (rtest3, CVT_IBM_SHORT, &rtemp3, CVT_VAX_F, 0);
  ret_stat = cvt_ftof (rtest4, CVT_IBM_SHORT, &rtemp4, CVT_VAX_F, 0);
/* printf ("get_cvt_args IBM to VAX rtemp1,rtemp2,rtemp3,rtemp4 %f %f %f %f\n",
 * rtemp1,rtemp2,rtemp3,rtemp4);
 */
  sprintf (buf,"%f %f %f %f\0",rtemp1,rtemp2,rtemp3,rtemp4);
  sscanf (buf,"%f %f %f %f",&rtemp1,&rtemp2,&rtemp3,&rtemp4);
  if (rtemp1 > -0.0001 && rtemp1 < 5.0 && rtemp2 > -0.0001 && rtemp2 < 10000.0
   && rtemp3 > -0.0001 && rtemp3 < 10.0 && rtemp4 > -0.0001 && rtemp4 < 1000.0
   && (rtemp1 + rtemp2 + rtemp3 + rtemp4) > 0.0001) {
    *cvt_arg_in = CVT_IBM_SHORT;
    *cvt_arg_out = CVT_VAX_F;
    return;
  }
  return;
}

int cvt_ftof (r_in, cvt_arg_in, r_out, cvt_arg_out, opt)
float *r_in, *r_out;
int cvt_arg_in, cvt_arg_out, opt;
{
  int i, itemp1, itemp2, *iptr;
  unsigned short int i2temp1, i2temp2, *i2ptr;
  int exp2, exp4, exp16, bit_shift;
  float rtemp1, rtemp2, *rptr;
  unsigned char mantissa_1, mantissa_2, mantissa_3, sign_bit, flagc, 
   carry, ctemp1, ctemp2, *cptr;

  rtemp1 = *r_in;
  if (cvt_arg_in == cvt_arg_out) {
    rtemp2 = rtemp1;
  }
  else {
    iptr = (int *)&rtemp1;
    itemp1 = *iptr;
    if (itemp1 == 0) {
      rtemp2 = 0.0;
      *r_out = rtemp2;
      return (0);
    }
    switch (cvt_arg_in) {
      case CVT_VAX_F:
        switch (cvt_arg_out) {
          case CVT_BIG_ENDIAN_IEEE_S:
            iptr = (int *)&rtemp1;
            itemp1 = *iptr;
            i2ptr = (unsigned short int *)&itemp1;         
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            cptr = (unsigned char *)&i2temp1;
            ctemp1 = *cptr;
            ctemp1--;
            *cptr = ctemp1;
            *i2ptr = i2temp1;
            i2ptr++;
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            *i2ptr = i2temp1;
            rptr = (float *)&itemp1;
            rtemp2 = *rptr;
          break;
          case CVT_IEEE_S:
            iptr = (int *)&rtemp1;
            itemp1 = *iptr;
            itemp2 = (( (itemp1)&0xFFFF) << 16) | 
             (( (itemp1)&0xFFFF0000) >> 16);
            i2ptr = (unsigned short int *)&itemp2;         
            i2ptr++;
            i2temp1 = *i2ptr;
            cptr = (unsigned char *)&i2temp1 + 1;
            ctemp1 = *cptr;
            ctemp1--;
            *cptr = ctemp1;
            *i2ptr = i2temp1;
            rptr = (float *)&itemp2;
            rtemp2 = *rptr;
          break;
          case CVT_IBM_SHORT:
            iptr = (int *)&rtemp1;
            itemp1 = *iptr;
            i2ptr = (unsigned short int *)&itemp1;         
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            cptr = (unsigned char *)&i2temp1;
            ctemp1 = *cptr;
            ctemp2 = (ctemp1 & 0x7F);
            exp4 = ctemp2;
            exp4 = exp4 - 64;
            sign_bit = (ctemp1 & 0x80);
            cptr++;
            ctemp2 = *cptr;
            flagc = (ctemp2 & 0x80);
            *i2ptr = i2temp1;
            i2ptr++;
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            *i2ptr = i2temp1;
            if (flagc == 0)
              exp2 = 2 * exp4 - 1;
            else
              exp2 = 2 * exp4;
            if (exp2 >= 0) {
              exp16 = (exp2 / 4) + 65;
              bit_shift = 3 - (exp2 - (4*(exp2/4)));
            }
            else {
              exp16 = -((-exp2 + 3)/4) + 65;
              bit_shift = 3 - (exp2 - (4*((exp2-3)/4)));
            }
            cptr = (unsigned char *)&itemp1;
            cptr++;
            mantissa_1 = (*cptr | 0x80);
            cptr++;
            mantissa_2 = *cptr;
            cptr++;
            mantissa_3 = *cptr;
            cptr = (unsigned char *)&itemp1;
            ctemp1 = exp16;
            ctemp1 = (ctemp1 | sign_bit);
            *cptr = ctemp1;
            if (bit_shift > 0) {
              for (i = 0; i < bit_shift; i++) {
                cptr = (unsigned char *)&itemp1 + 1;
                ctemp1 = mantissa_1/2;
                carry = 0;
                if ((mantissa_1 - 2*(mantissa_1/2)) != 0)
                  carry = 0x80;
                *cptr = ctemp1;
                mantissa_1 = ctemp1;
                cptr++;
                ctemp1 = ((mantissa_2/2) | carry);
                carry = 0;
                if ((mantissa_2 - 2*(mantissa_2/2)) != 0)
                  carry = 0x80;
                *cptr = ctemp1;
                mantissa_2 = ctemp1;
                cptr++;
                ctemp1 = ((mantissa_3/2) | carry);
                *cptr = ctemp1;
                mantissa_3 = ctemp1;
              }
            }
            else {
              cptr++;
              *cptr = mantissa_1;
              cptr++;
              *cptr = mantissa_2;
              cptr++;
              *cptr = mantissa_3;
            }
            rptr = (float *)&itemp1;
            rtemp2 = *rptr;
          break;
        }
      break;
      case CVT_BIG_ENDIAN_IEEE_S:  
        switch (cvt_arg_out) {
          case CVT_IEEE_S:                  /* Just swap byte order */
            iptr = (int *)&rtemp1;
            itemp1 = *iptr;
            i2ptr = (unsigned short int *)&itemp1;         
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            *i2ptr = i2temp1;
            i2ptr++;
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            *i2ptr = i2temp1;
            itemp2 = (( (itemp1)&0xFFFF) << 16) | 
             (( (itemp1)&0xFFFF0000) >> 16);
            rptr = (float *)&itemp2;
            rtemp2 = *rptr;
          break;
          case CVT_IBM_SHORT:
            iptr = (int *)&rtemp1;
            itemp1 = *iptr;
            i2ptr = (unsigned short int *)&itemp1;         
            i2temp1 = *i2ptr;
            cptr = (unsigned char *)&i2temp1;
            ctemp1 = *cptr;
            ctemp2 = (ctemp1 & 0x7F);
            exp4 = ctemp2;
            exp4 = exp4 - 63;
            sign_bit = (ctemp1 & 0x80);
            cptr++;
            ctemp2 = *cptr;
            flagc = (ctemp2 & 0x80);
            if (flagc == 0)
              exp2 = 2 * exp4 - 1;
            else
              exp2 = 2 * exp4;
            if (exp2 >= 0) {
              exp16 = (exp2 / 4) + 65;
              bit_shift = 3 - (exp2 - (4*(exp2/4)));
            }
            else {
              exp16 = -((-exp2 + 3)/4) + 65;
              bit_shift = 3 - (exp2 - (4*((exp2-3)/4)));
            }
            cptr = (unsigned char *)&itemp1;
            cptr++;
            mantissa_1 = (*cptr | 0x80);
            cptr++;
            mantissa_2 = *cptr;
            cptr++;
            mantissa_3 = *cptr;
            cptr = (unsigned char *)&itemp1;
            ctemp1 = exp16;
            ctemp1 = (ctemp1 | sign_bit);
            *cptr = ctemp1;
            if (bit_shift > 0) {
              for (i = 0; i < bit_shift; i++) {
                cptr = (unsigned char *)&itemp1 + 1;
                ctemp1 = mantissa_1/2;
                carry = 0;
                if ((mantissa_1 - 2*(mantissa_1/2)) != 0)
                  carry = 0x80;
                *cptr = ctemp1;
                mantissa_1 = ctemp1;
                cptr++;
                ctemp1 = ((mantissa_2/2) | carry);
                carry = 0;
                if ((mantissa_2 - 2*(mantissa_2/2)) != 0)
                  carry = 0x80;
                *cptr = ctemp1;
                mantissa_2 = ctemp1;
                cptr++;
                ctemp1 = ((mantissa_3/2) | carry);
                *cptr = ctemp1;
                mantissa_3 = ctemp1;
              }
            }
            else {
              cptr++;
              *cptr = mantissa_1;
              cptr++;
              *cptr = mantissa_2;
              cptr++;
              *cptr = mantissa_3;
            }
            rptr = (float *)&itemp1;
            rtemp2 = *rptr;
          break;
          case CVT_VAX_F:
            iptr = (int *)&rtemp1;
            itemp1 = *iptr;
            i2ptr = (unsigned short int *)&itemp1;         
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            cptr = (unsigned char *)&i2temp1 + 1;
            ctemp1 = *cptr;
            ctemp1++;
            *cptr = ctemp1;
            *i2ptr = i2temp1;
            i2ptr++;
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            *i2ptr = i2temp1;
            rptr = (float *)&itemp1;
            rtemp2 = *rptr;
          break;
        }
      break;
      case CVT_IEEE_S:
        switch (cvt_arg_out) {
          case CVT_IBM_SHORT:
            iptr = (int *)&rtemp1;
            itemp1 = *iptr;
            i2ptr = (unsigned short int *)&itemp1;         
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            *i2ptr = i2temp1;
            i2ptr++;
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            cptr = (unsigned char *)&i2temp1;
            ctemp1 = *cptr;
            ctemp2 = (ctemp1 & 0x7F);
            exp4 = ctemp2;
            exp4 = exp4 - 63;
            sign_bit = (ctemp1 & 0x80);
            cptr++;
            ctemp2 = *cptr;
            flagc = (ctemp2 & 0x80);
            *i2ptr = i2temp1;
            itemp2 = (( (itemp1)&0xFFFF) << 16) | 
             (( (itemp1)&0xFFFF0000) >> 16);
            if (flagc == 0)
              exp2 = 2 * exp4 - 1;
            else
              exp2 = 2 * exp4;
            if (exp2 >= 0) {
              exp16 = (exp2 / 4) + 65;
              bit_shift = 3 - (exp2 - (4*(exp2/4)));
            }
            else {
              exp16 = -((-exp2 + 3)/4) + 65;
              bit_shift = 3 - (exp2 - (4*((exp2-3)/4)));
            }
            cptr = (unsigned char *)&itemp2;
            cptr++;
            mantissa_1 = (*cptr | 0x80);
            cptr++;
            mantissa_2 = *cptr;
            cptr++;
            mantissa_3 = *cptr;
            cptr = (unsigned char *)&itemp1;
            ctemp1 = exp16;
            ctemp1 = (ctemp1 | sign_bit);
            *cptr = ctemp1;
            if (bit_shift > 0) {
              for (i = 0; i < bit_shift; i++) {
                cptr = (unsigned char *)&itemp1 + 1;
                ctemp1 = mantissa_1/2;
                carry = 0;
                if ((mantissa_1 - 2*(mantissa_1/2)) != 0)
                  carry = 0x80;
                *cptr = ctemp1;
                mantissa_1 = ctemp1;
                cptr++;
                ctemp1 = ((mantissa_2/2) | carry);
                carry = 0;
                if ((mantissa_2 - 2*(mantissa_2/2)) != 0)
                  carry = 0x80;
                *cptr = ctemp1;
                mantissa_2 = ctemp1;
                cptr++;
                ctemp1 = ((mantissa_3/2) | carry);
                *cptr = ctemp1;
                mantissa_3 = ctemp1;
              }
            }
            else {
              cptr++;
              *cptr = mantissa_1;
              cptr++;
              *cptr = mantissa_2;
              cptr++;
              *cptr = mantissa_3;
            }
            rptr = (float *)&itemp1;
            rtemp2 = *rptr;
          break;
          case CVT_VAX_F:
            iptr = (int *)&rtemp1;
            itemp1 = *iptr;
            i2ptr = (unsigned short int *)&itemp1;         
            i2ptr++;
            i2temp1 = *i2ptr;
            cptr = (unsigned char *)&i2temp1 + 1;
            ctemp1 = *cptr;
            ctemp1++;
            *cptr = ctemp1;
            *i2ptr = i2temp1;
            itemp2 = (( (itemp1)&0xFFFF) << 16) | 
             (( (itemp1)&0xFFFF0000) >> 16);
            rptr = (float *)&itemp2;
            rtemp2 = *rptr;
          break;
          case CVT_BIG_ENDIAN_IEEE_S:        /* Just swap byte order */
            iptr = (int *)&rtemp1;
            itemp1 = *iptr;
            i2ptr = (unsigned short int *)&itemp1;         
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            *i2ptr = i2temp1;
            i2ptr++;
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            *i2ptr = i2temp1;
            itemp2 = (( (itemp1)&0xFFFF) << 16) | 
             (( (itemp1)&0xFFFF0000) >> 16);
            rptr = (float *)&itemp2;
            rtemp2 = *rptr;
          break;
        }
      break;
      case CVT_IBM_SHORT:
        iptr = (int *)&rtemp1;
        itemp1 = *iptr;
        cptr = (unsigned char *)&itemp1;
        cptr++;
        mantissa_1 = (*cptr | 0x80);
        cptr++;
        mantissa_2 = *cptr;
        cptr++;
        mantissa_3 = *cptr;
        if ((mantissa_1 & 0x80) != 0)
          bit_shift = 0;
        else if ((mantissa_1 & 0x40) != 0)
          bit_shift = 1;
        else if ((mantissa_1 & 0x20) != 0)
          bit_shift = 2;
        else
          bit_shift = 3;
        if (bit_shift > 0) {
          for (i = 0; i < bit_shift; i++) {
            carry = mantissa_3/128;
            mantissa_3 = (mantissa_3 << 1);
            ctemp1 = (mantissa_2 << 1) + carry;
            carry = mantissa_2/128;
            mantissa_2 = ctemp1;
            mantissa_1 = (mantissa_1 << 1) + carry;
          }
        }
        i2ptr = (unsigned short int *)&itemp1;         
        i2temp1 = *i2ptr;
        cptr = (unsigned char *)&i2temp1;
        ctemp1 = *cptr;
        ctemp2 = (ctemp1 & 0x7F);
        exp16 = ctemp2;
        exp16 = exp16 - 64;
        sign_bit = (ctemp1 & 0x80);
        exp2 = (exp16 - 1) * 4 + 3 - bit_shift;
        if ((exp2 - 2*(exp2/2)) == 0) {
          exp4 = exp2/2;
        }
        else {
          exp4 = (exp2+1)/2;
          mantissa_1 = (mantissa_1 & 0x7F);
        } 
        cptr = (unsigned char *)&itemp1;
        switch (cvt_arg_out) {
          case CVT_VAX_F:
            ctemp1 = exp2 + 64;
            ctemp1 = (ctemp1 | sign_bit);
            *cptr = ctemp1;
            cptr++;
            *cptr = mantissa_1;
            cptr++;
            *cptr = mantissa_2;
            cptr++;
            *cptr = mantissa_3;
            i2ptr = (unsigned short int *)&itemp1;         
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            *i2ptr = i2temp1;
            i2ptr++;
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            *i2ptr = i2temp1;
            rptr = (float *)&itemp1;
            rtemp2 = *rptr;
          break;
          case CVT_BIG_ENDIAN_IEEE_S:
            ctemp1 = exp2 + 63;
            ctemp1 = (ctemp1 | sign_bit);
            *cptr = ctemp1;
            cptr++;
            *cptr = mantissa_1;
            cptr++;
            *cptr = mantissa_2;
            cptr++;
            *cptr = mantissa_3;
            rptr = (float *)&itemp1;
            rtemp2 = *rptr;
          break;
          case CVT_IEEE_S:
            ctemp1 = exp2 + 63;
            ctemp1 = (ctemp1 | sign_bit);
            *cptr = ctemp1;
            cptr++;
            *cptr = mantissa_1;
            cptr++;
            *cptr = mantissa_2;
            cptr++;
            *cptr = mantissa_3;
            itemp2 = itemp1;
            i2ptr = (unsigned short int *)&itemp2;         
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            *i2ptr = i2temp1;
            i2ptr++;
            i2temp1 = (( (*i2ptr)&0xFF) << 8) | (( (*i2ptr)&0xFF00) >> 8);
            *i2ptr = i2temp1;
            itemp1 = (( (itemp2)&0xFFFF) << 16) | 
             (( (itemp2)&0xFFFF0000) >> 16);
            rptr = (float *)&itemp1;
            rtemp2 = *rptr;
          break;
        }
      break;
    }
  }
  *r_out = rtemp2;
  return (0);
}

/******************************************************************************/

void unpack_word(int fd, int x, int y, short int *img)

/* Unpacks a packed image into the WORD-array 'img'. The image is open on
   descriptor fd. The file should be properly positioned: the first BYTE
   read is assumed to be the first BYTE of the packed image. */

{ int valids = 0, spillbits = 0, usedbits, total = x * y;
  int window = 0, spill, pixel = 0, nextint, bitnum, pixnum;
  static int bitdecode[8] = {0, 4, 5, 6, 7, 8, 16, 32};

  FILE *packfile;

  packfile = fdopen(fd,"r");

  while (pixel < total)
  { if (valids < 6) 
    { if (spillbits > 0)
      { window |= shift_left(spill, valids);
	valids += spillbits;
	spillbits = 0;}
      else
      { spill = (int) getc(packfile);
	spillbits = 8;}}
    else
    { pixnum = 1 << (window & setbits[3]);
      window = shift_right(window, 3);
      bitnum = bitdecode[window & setbits[3]];
      window = shift_right(window, 3);
      valids -= 6;
      while ((pixnum > 0) && (pixel < total))
      { if (valids < bitnum)
	{ if (spillbits > 0)
	  { window |= shift_left(spill, valids);
	    if ((32 - valids) > spillbits)
	    { valids += spillbits;
	      spillbits = 0;}
	    else
	    { usedbits = 32 - valids;
	      spill = shift_right(spill, usedbits);
	      spillbits -= usedbits;
	      valids = 32;}}
	  else
	  { spill = (int) getc(packfile);
	    spillbits = 8;}}
        else
	{ --pixnum;
	  if (bitnum == 0)
            nextint = 0;
	  else
	  { nextint = window & setbits[bitnum];
	    valids -= bitnum;
	    window = shift_right(window, bitnum);
	    if ((nextint & (1 << (bitnum - 1))) != 0)
	      nextint |= ~setbits[bitnum];}
	  if (pixel > x)
	  { img[pixel] = (short int) (nextint + 
				      (img[pixel-1] + img[pixel-x+1] + 
                                       img[pixel-x] + img[pixel-x-1] + 2) / 4);
	    ++pixel;}
	  else if (pixel != 0)
	  { img[pixel] = (short int) (img[pixel - 1] + nextint);
	    ++pixel;}
	  else
	    img[pixel++] = (short int) nextint;}}}}}

/******************************************************************************/

void v2unpack_word(int fd, int x, int y, short int *img)

/* Unpacks a packed image into the WORD-array 'img'. The image is opened on
   descriptor fd. The file should be properly positioned: the first BYTE
   read is assumed to be the first BYTE of the packed image. */

{ int valids = 0, spillbits = 0, usedbits, total = x * y;
  int window = 0, spill, pixel = 0, nextint, bitnum, pixnum;
  static int bitdecode[16] = {0, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 
                              16, 32};

  FILE *packfile;

  packfile = fdopen (fd,"r");

  while (pixel < total)
  { if (valids < 7) 
    { if (spillbits > 0)
      { window |= shift_left(spill, valids);
	valids += spillbits;
	spillbits = 0;}
      else
      { spill = (int) getc(packfile);
	spillbits = 8;}}
    else
    { pixnum = 1 << (window & setbits[3]);
      window = shift_right(window, 3);
      bitnum = bitdecode[window & setbits[4]];
      window = shift_right(window, 4);
      valids -= 7;
      while ((pixnum > 0) && (pixel < total))
      { if (valids < bitnum)
	{ if (spillbits > 0)
	  { window |= shift_left(spill, valids);
	    if ((32 - valids) > spillbits)
	    { valids += spillbits;
	      spillbits = 0;}
	    else
	    { usedbits = 32 - valids;
	      spill = shift_right(spill, usedbits);
	      spillbits -= usedbits;
	      valids = 32;}}
	  else
	  { spill = (int) getc(packfile);
	    spillbits = 8;}}
        else
	{ --pixnum;
	  if (bitnum == 0)
            nextint = 0;
	  else
	  { nextint = window & setbits[bitnum];
	    valids -= bitnum;
	    window = shift_right(window, bitnum);
	    if ((nextint & (1 << (bitnum - 1))) != 0)
	      nextint |= ~setbits[bitnum];}
 	  if (pixel > x)
	  { img[pixel] = (short int) (nextint + 
				      (img[pixel-1] + img[pixel-x+1] + 
                                       img[pixel-x] + img[pixel-x-1] + 2) / 4);
	    ++pixel;}
	  else if (pixel != 0)
	  { img[pixel] = (short int) (img[pixel - 1] + nextint);
	    ++pixel;}
	  else
	    img[pixel++] = (short int) nextint;}}}}}

